# Music Project for SpringBoot

## EntityDesign

### Music
	+ id 
	+ musicName
	+ musicSingerName
	+ musicSingerId
	+ musicCompose
	+ musicLyrics
	+ musicDuration
	+ musicAlbum
	+ musicAlbumId
	+ musicUrl
	+ musicTime
	+ gmtModified
	+ gmtCreate
	+ isOnline
	+ musicVisited
	+ musicCollected
	