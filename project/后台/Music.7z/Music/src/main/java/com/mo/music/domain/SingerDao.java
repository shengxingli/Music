package com.mo.music.domain;

import java.math.BigInteger;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

/**
 * SingerDao
 */
@Mapper
public interface SingerDao {

	/**
	 * 插入
	 * @param singer
	 */
	@Insert("INSERT INTO singer (singer_name, singer_avatar, count_music, count_album, status, gmt_create, gmt_modified) VALUES (#{singerName}, #{singerAvatar}, #{countMusic}, #{countAlbum}, #{status}, #{gmtCreate}, #{gmtModified})")
	@SelectKey(statement="SELECT LAST_INSERT_ID()" ,keyProperty="id", before=false, resultType=java.math.BigInteger.class)
	void insertSinger(Singer singer);

	/**
	 * 更新状态
	 * @param id
	 * @param isEnter
	 */
	@Update("UPDATE singer SET status=#{status} WHERE id=#{id}")
	void updateSingerEnterStatus(@Param("id") BigInteger id, @Param("status") int status);

	/**
	 * 更新歌手
	 * @param id
	 * @param singerName
	 */
	@Update("UPDATE singer SET singer_name=#{singerName}, singer_avatar=#{singerAvatar} WHERE id=#{id}")
	void updateSingerById(@Param("id") BigInteger id, @Param("singerName") String singerName, @Param("singerAvatar") String singerAvatar);

	/**
	 * 查询单个歌手
	 * @param singer
	 * @return
	 */
	@Select("SELECT id, singer_name, singer_avatar, count_music, count_album, status, gmt_create, gmt_modified FROM singer WHERE id=#{id}")
	Singer querySingerById(BigInteger id);

	/**
	 * 模糊查询歌手
	 * @param name
	 * @param limit
	 * @param offset
	 * @return
	 */
	@Select("SELECT id, singer_name, singer_avatar, count_music, count_album, status, gmt_create, gmt_modified FROM singer WHERE singer_name LIKE CONCAT('%%',#{name},'%%') LIMIT #{limit} OFFSET #{offset}")
	List<Singer> querySinger(@Param("name") String name , @Param("limit") int limit, @Param("offset") int offset);

	/**
	 * 统计
	 * @param name
	 * @return
	 */
	@Select("SELECT COUNT(id) FROM singer WHERE singer_name LIKE CONCAT('%%',#{name},'%%')")
	Integer countSingerNumberBySingerName(@Param("name") String name);
	

	/**
	 * 自增更新歌曲数量
	 * @param id
	 */
	@Update("UPDATE singer SET count_music=count_music+1 WHERE id=#{id}")
	void increaseSingerMusicCount(BigInteger id);

	/**
	 * 自减歌曲数量
	 * @param id
	 */
	@Update("UPDATE singer SET count_music=count_music-1 WHERE id=#{id}")
	void reduceSingerMusicCount(BigInteger id);

	/**
	 * 自增专辑数量
	 * @param id
	 */
	@Update("UPDATE singer SET count_album=count_album+1 WHERE id=#{id}")
	void increaseSingerAlbumCount(BigInteger id);

	/**
	 * 自减专辑数量
	 * @param id
	 */
	@Update("UPDATE singer SET count_album=count_album-1 WHERE id=#{id}")
	void reduceSingerAlbumCount(BigInteger id);


	
	/**
	 * 最新入驻歌手
	 * @return
	 */
	@Select("SELECT id, singer_name, singer_avatar, count_music, count_album, status, gmt_create, gmt_modified FROM singer ORDER BY gmt_create DESC LIMIT 50")
	List<Singer> queryNewSinger();

	/**
	 * 随机推荐歌手
	 * @return
	 */
	@Select("SELECT id, singer_name, singer_avatar, count_music, count_album, status, gmt_create, gmt_modified FROM singer  WHERE id >= ((SELECT MAX(id) FROM singer)-(SELECT MIN(id) FROM singer)) * RAND() + (SELECT MIN(id) FROM singer)  LIMIT 50")
	List<Singer> queryRandomSinger();
}