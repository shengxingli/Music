package com.mo.music.core;

import java.beans.PropertyVetoException;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan("com.mo.music.dao")
public class DataSourceConfiguration {
	@Value("${jdbc.url}")
	private String jdbcUrl;
	@Value("${jdbc.driver-class-name}")
	private String jdbcDriver;
	@Value("${jdbc.name}")
	private String user;
	@Value("${jdbc.password}")
	private String password;

	@Bean(name = "dataSource")
	public ComboPooledDataSource dataSource() throws PropertyVetoException {
		ComboPooledDataSource dataSource = new ComboPooledDataSource();
		dataSource.setDriverClass(jdbcDriver);
		dataSource.setJdbcUrl(jdbcUrl);
		dataSource.setUser(user);
		dataSource.setPassword(password);
		dataSource.setMaxIdleTime(14400);
		// 关闭连接池后是否自动提交
		dataSource.setAutoCommitOnClose(false);
        return dataSource;
    };
}
