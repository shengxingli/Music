package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;

/**
 * Lyric
 */
public class Lyric {

	private BigInteger id;
	
	private BigInteger musicId;

	private String lyric;

	private Timestamp gmtCreate;

	private Timestamp gmtModified;

	public BigInteger getId() {
		return id;
	}

	public void setId(BigInteger id) {
		this.id = id;
	}

	public BigInteger getMusicId() {
		return musicId;
	}

	public void setMusicId(BigInteger musicId) {
		this.musicId = musicId;
	}

	public String getLyric() {
		return lyric;
	}

	public void setLyric(String lyric) {
		this.lyric = lyric;
	}

	public Timestamp getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Timestamp gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Timestamp getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Timestamp gmtModified) {
		this.gmtModified = gmtModified;
	}
}