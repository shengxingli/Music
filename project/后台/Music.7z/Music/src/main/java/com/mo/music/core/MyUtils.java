package com.mo.music.core;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

/**
 * MyUtils
 */
public class MyUtils {

	public static String getRequestParam(String key, HttpServletRequest httpServletRequest) {
		Cookie[] cookies = httpServletRequest.getCookies();
		String str = "";
		if (cookies != null) {
			for (Cookie c : cookies) {
				if (c.getName().equals(key)) {
					str = c.getValue();
				}
			}
		}
		String paramT = httpServletRequest.getParameter(key);
		if (paramT != null) {
			str = paramT;
		}
		return str;
	}
}