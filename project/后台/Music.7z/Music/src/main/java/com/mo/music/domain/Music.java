package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;

/**
 * Music
 */
public class Music {
	/** 主键音乐ID */
	private BigInteger id;

	/** 歌曲名称 */
	private String musicName;

	/** 歌手名称 */
	private String musicSingerName;

	/** 歌手id */
	private BigInteger musicSingerId;

	/** 作曲 */
	private String musicCompose;

	/** 作词 */
	private String musicLyrics;

	/** 歌曲时长 */
	private Integer musicDuration;

	/** 歌曲专辑 */
	private String musicAlbum;

	/** 歌曲专辑 */
	private BigInteger musicAlbumId;

	/** 歌曲地址 */
	private String musicUrl;

	/** 创作时间 */
	private Timestamp musicTime;

	/** 更新时间 */
	private Timestamp gmtModified;

	/** 入库时间 */
	private Timestamp gmtCreate;

	/** 状态 */
	private Integer isOnline;

	/** 访问数量 */
	private BigInteger countVisited;

	/** 收藏数量 */
	private BigInteger countCollected;

	/**
	 * @return the isOnline
	 */
	public Integer getIsOnline() {
		return isOnline;
	}

	/**
	 * @param isOnline the isOnline to set
	 */
	public void setIsOnline(Integer isOnline) {
		this.isOnline = isOnline;
	}

	/**
	 * @return the gmtCreate
	 */
	public Timestamp getGmtCreate() {
		return gmtCreate;
	}

	/**
	 * @param gmtCreate the gmtCreate to set
	 */
	public void setGmtCreate(Timestamp gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	/**
	 * @return the gmtModified
	 */
	public Timestamp getGmtModified() {
		return gmtModified;
	}

	/**
	 * @param gmtModified the gmtModified to set
	 */
	public void setGmtModified(Timestamp gmtModified) {
		this.gmtModified = gmtModified;
	}

	/**
	 * @return the musicTime
	 */
	public Timestamp getMusicTime() {
		return musicTime;
	}

	/**
	 * @param musicTime the musicTime to set
	 */
	public void setMusicTime(Timestamp musicTime) {
		this.musicTime = musicTime;
	}

	/**
	 * @return the id
	 */
	public BigInteger getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(BigInteger id) {
		this.id = id;
	}

	/**
	 * @return the musicAlbumId
	 */
	public BigInteger getMusicAlbumId() {
		return musicAlbumId;
	}

	/**
	 * @param musicAlbumId the musicAlbumId to set
	 */
	public void setMusicAlbumId(BigInteger musicAlbumId) {
		this.musicAlbumId = musicAlbumId;
	}


	/**
	 * @return the musicUrl
	 */
	public String getMusicUrl() {
		return musicUrl;
	}

	/**
	 * @param musicUrl the musicUrl to set
	 */
	public void setMusicUrl(String musicUrl) {
		this.musicUrl = musicUrl;
	}

	/**
	 * @return the musicAlbum
	 */
	public String getMusicAlbum() {
		return musicAlbum;
	}

	/**
	 * @param musicAlbum the musicAlbum to set
	 */
	public void setMusicAlbum(String musicAlbum) {
		this.musicAlbum = musicAlbum;
	}

	/**
	 * @return the musicDuration
	 */
	public Integer getMusicDuration() {
		return musicDuration;
	}

	/**
	 * @param musicDuration the musicDuration to set
	 */
	public void setMusicDuration(Integer musicDuration) {
		this.musicDuration = musicDuration;
	}

	/**
	 * @return the musicLyrics
	 */
	public String getMusicLyrics() {
		return musicLyrics;
	}

	/**
	 * @param musicLyrics the musicLyrics to set
	 */
	public void setMusicLyrics(String musicLyrics) {
		this.musicLyrics = musicLyrics;
	}

	/**
	 * @return the musicCompose
	 */
	public String getMusicCompose() {
		return musicCompose;
	}

	/**
	 * @param musicCompose the musicCompose to set
	 */
	public void setMusicCompose(String musicCompose) {
		this.musicCompose = musicCompose;
	}

	/**
	 * @return the musicName
	 */
	public String getMusicName() {
		return musicName;
	}

	/**
	 * @param musicName the musicName to set
	 */
	public void setMusicName(String musicName) {
		this.musicName = musicName;
	}

	public String getMusicSingerName() {
		return musicSingerName;
	}

	public void setMusicSingerName(String musicSingerName) {
		this.musicSingerName = musicSingerName;
	}

	public BigInteger getMusicSingerId() {
		return musicSingerId;
	}

	public void setMusicSingerId(BigInteger musicSingerId) {
		this.musicSingerId = musicSingerId;
	}

	public BigInteger getCountVisited() {
		return countVisited;
	}

	public void setCountVisited(BigInteger countVisited) {
		this.countVisited = countVisited;
	}

	public BigInteger getCountCollected() {
		return countCollected;
	}

	public void setCountCollected(BigInteger countCollected) {
		this.countCollected = countCollected;
	}

}