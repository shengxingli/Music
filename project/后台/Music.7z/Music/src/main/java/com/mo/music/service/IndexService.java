package com.mo.music.service;

import java.util.List;

import com.mo.music.domain.Music;
import com.mo.music.domain.MusicDao;
import com.mo.music.domain.Singer;
import com.mo.music.domain.SingerDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * IndexService
 */
@Service
public class IndexService {

    @Autowired
    MusicDao musicDao;

    @Autowired
    SingerDao singerDao;
    
	/**
	 * 查询全网最热音乐
	 * @return
	 */
	public List<Music> queryHotMusic() {
		return musicDao.queryHotMusic();
	}

	/**
	 * 查询全网最新音乐
	 * @return
	 */
	public List<Music> queryNewMusic() {
		return musicDao.queryNewMusic();
    }
    
    /**
     * 查询最新入驻歌手
     * @return
     */
    public List<Singer> queryNewSinger() {
        return singerDao.queryNewSinger();
    }

    /**
     * 随机推荐歌手
     * @return
     */
    public List<Singer> queryRandomSinger() {
        return singerDao.queryRandomSinger();
    }
	
}