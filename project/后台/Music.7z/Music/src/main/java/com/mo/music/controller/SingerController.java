package com.mo.music.controller;

import java.math.BigInteger;
import java.util.List;

import com.mo.music.core.MyList;
import com.mo.music.core.MyResult;
import com.mo.music.domain.Album;
import com.mo.music.domain.Music;
import com.mo.music.domain.Singer;
import com.mo.music.service.AlbumService;
import com.mo.music.service.MusicService;
import com.mo.music.service.SingerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * SingerController
 */
@RestController
@RequestMapping("/singer")
public class SingerController {

    @Autowired
    private SingerService singerService;

    @Autowired
    private AlbumService albumService;

    @Autowired
    private MusicService musicService;

	/**
	 * 查询详情
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/info", method = RequestMethod.POST)
    public MyResult<Singer> querySingerById(BigInteger id) {
        MyResult<Singer> myResult = new MyResult<>();
        Singer singer =  singerService.querySingerById(id);
		List<Music> list =  musicService.queryHotMusicBySingerId(id);
		singer.setHotSong(list);
        myResult.setData(singer);
        return myResult;
    }
	
	@RequestMapping(value = "/music", method = RequestMethod.POST) 
	public MyResult<MyList<Music>> querySingerMusic(BigInteger id, @RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(defaultValue = "10") Integer pageSize) {
		MyResult<MyList<Music>> myResult = new MyResult<>();
		MyList<Music> list = musicService.queryMusicBySingerId(id, pageNum, pageSize);
		myResult.setData(list);
		return myResult;
	}

	/**
	 * 查询专
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/album", method = RequestMethod.POST )
	public MyResult<List<Album>> querySingerAlbum(BigInteger id) {
		MyResult<List<Album>> myResult = new MyResult<>();
		List<Album> list = albumService.querySingerAlbumBySingerId(id);
		myResult.setData(list);
		return myResult;
	}
}