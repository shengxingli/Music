package com.mo.music.controller;

import java.util.List;

import com.mo.music.core.MyResult;
import com.mo.music.domain.Music;
import com.mo.music.domain.Singer;
import com.mo.music.service.IndexService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * IndexController
 */
@RestController
@RequestMapping("/index")
public class IndexController {

	@Autowired
	private IndexService indexService;

	@RequestMapping(value = "/hotMusic", method = RequestMethod.POST)
	public MyResult<List<Music>> queryHotMusic() {
		MyResult<List<Music>> myResult = new MyResult<>();
		List<Music> list = indexService.queryHotMusic();
		myResult.setData(list);
		return myResult;
	}

	@RequestMapping(value = "/newMusic", method = RequestMethod.POST)
	public MyResult<List<Music>> queryNewMusic() {
		MyResult<List<Music>> myResult = new MyResult<>();
		List<Music> list = indexService.queryNewMusic();
		myResult.setData(list);
		return myResult;
	}

	@RequestMapping(value = "/newSinger", method = RequestMethod.POST)
	public MyResult<List<Singer>> queryNewSinger() {
		MyResult<List<Singer>> myResult = new MyResult<>();
		List<Singer> list = indexService.queryNewSinger();
		myResult.setData(list);
		return myResult;
	}

	@RequestMapping(value = "/recommendSinger", method = RequestMethod.POST)
	public MyResult<List<Singer>> queryRandomSinger() {
		MyResult<List<Singer>> myResult = new MyResult<>();
		List<Singer> list = indexService.queryRandomSinger();
		myResult.setData(list);
		return myResult;
	}
}