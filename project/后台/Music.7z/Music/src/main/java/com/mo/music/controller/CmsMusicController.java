package com.mo.music.controller;

import java.math.BigInteger;

import com.mo.music.core.MyException;
import com.mo.music.core.MyList;
import com.mo.music.core.MyResult;
import com.mo.music.domain.Music;
import com.mo.music.service.MusicService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


/**
 * CmsMusicController
 */
@RestController
@RequestMapping("/cms/music")
public class CmsMusicController {

	@Autowired
	private MusicService musicService;
	
	@RequestMapping(value="/list", method=RequestMethod.POST)
	public MyResult<MyList<Music>> getList(@RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(defaultValue = "10") Integer pageSize, @RequestParam(required = false) String name) {
		MyResult<MyList<Music>> myResult = new MyResult<MyList<Music>>();
		myResult.setData(musicService.queryMusicByMusicName(name == null ? "" : name, pageNum, pageSize));
		return myResult;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public MyResult<?> editMusic(Music music) {
		if (music != null) {
			if (music.getMusicName() == null) {
				throw new MyException("名称不能为空", 400);
			}
			if (music.getMusicSingerId() == null) {
				throw new MyException("歌手不能为空", 400);
			}
			if (music.getMusicUrl() == null) {
				throw new MyException("地址不能为空", 400);
			}
		}
		if (music.getId() != null) {
			Music checkMusic = musicService.queryMusicById(music.getId(), true);
			if (checkMusic == null) {
				throw new MyException("该音乐不存在", 400);
			}
 			musicService.editMusic(music);
		} else {
			musicService.createMusic(music);
		}
		return new MyResult<>();
	}
	

	@RequestMapping(value = "/info", method = RequestMethod.POST)
	public MyResult<Music> queryMusicInfo(BigInteger id) {
		MyResult<Music> myResult = new MyResult<Music>();
		myResult.setData(musicService.queryMusicById(id, true));
		return myResult;
	}
	
	@RequestMapping(value = "/enable", method = RequestMethod.POST)
	public MyResult<?> enableMusic(BigInteger id) {
		try {
			musicService.ableMusicById(id, 1);
			return new MyResult<>();
		} catch (Exception e) {
			throw new MyException("启用失败", 400);
		}
	}
	
	@RequestMapping(value = "/disable", method = RequestMethod.POST)
	public MyResult<?> disableMusic(BigInteger id) {
		try {
			musicService.ableMusicById(id, 0);
			return new MyResult<>();
		} catch (Exception e) {
			throw new MyException("禁用失败", 400);
		}
	}

}