package com.mo.music.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import com.mo.music.core.MyException;
import com.mo.music.core.MyList;
import com.mo.music.domain.Singer;
import com.mo.music.domain.SingerDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * SingerService
 */
@Service
public class SingerService {

	@Autowired
	private SingerDao singerDao;

	/**
	 * 查询
	 * @param id
	 * @return
	 */
	public Singer querySingerById(BigInteger id) {
		try {
			return singerDao.querySingerById(id);
		} catch (Exception e) {
			throw new MyException("未找到该歌手信息", 404);
		}
	}

	public MyList<Singer> queryAllSinger(String name, Integer pageNum, Integer pageSize) {
		if (pageNum == null || pageNum < 1) {
			throw new MyException("pageNum不正确", 400);
		}
		int offset = (pageNum - 1) * pageSize;
		List<Singer> list = singerDao.querySinger(name, pageSize, offset);
		Integer total = singerDao.countSingerNumberBySingerName(name);
		MyList<Singer> myList = new MyList<>(list, total, pageNum, pageSize);
		return myList;
	}

	/**
	 * 新增
	 * @param singer
	 */
	public void insertSinger(Singer singer) {
		if (singer.getSingerName() == null || singer.getSingerName().equals("")) {
			throw new MyException("歌手名称不能为空", 400);
		}
		if (singer.getStatus() == null) {
			singer.setStatus(1);
		}
		singer.setCountAlbum(0);
		singer.setCountMusic(0);
		Timestamp current = new Timestamp(System.currentTimeMillis());
		singer.setGmtCreate(current);
		singer.setGmtModified(current);
		singerDao.insertSinger(singer);
		System.out.println(singer.getId());
	}

	/**
	 * 更新名称
	 * @param id
	 * @param singerName
	 */
	public void updateSingerName(BigInteger id, String singerName,String singerAvatar) {
		if (singerName == null || singerName.trim().equals("")) {
			throw new MyException("名称不正确", 400);
		}
		if (singerName.length() > 10) {
			throw new MyException("名称长度不能大于10", 400);
		}
		singerDao.updateSingerById(id, singerName, singerAvatar);
	}

	/**
	 * music自增
	 * @param id
	 */
	public void increaseMusicCount(BigInteger id) {
		singerDao.increaseSingerMusicCount(id);
	}

	/**
	 * music自减
	 * @param id
	 */
	public void reduceMusicCount(BigInteger id) {
		singerDao.reduceSingerMusicCount(id);
	}

	/**
	 * album自增
	 * @param id
	 */
	public void increaseAlbumCount(BigInteger id) {
		singerDao.increaseSingerAlbumCount(id);
	}

	/**
	 * album自减
	 * @param id
	 */
	public void reduceAlbumCount(BigInteger id) {
		singerDao.reduceSingerAlbumCount(id);
	}

	/**
	 * 审核通过
	 * @param id
	 */
	public void updateSingerPassing(BigInteger id) {
		singerDao.updateSingerEnterStatus(id, 1);
	}

	/**
	 * 入驻
	 * @param id
	 */
	public void updateSingerEntering(BigInteger id) {
		singerDao.updateSingerEnterStatus(id, 1);
	}

	/**
	 * 隐藏
	 * @param id
	 */
	public void updateSingerOutEnter(BigInteger id) {
		singerDao.updateSingerEnterStatus(id, 0);
	}
}