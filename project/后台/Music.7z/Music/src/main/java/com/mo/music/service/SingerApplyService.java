package com.mo.music.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import com.mo.music.core.MyException;
import com.mo.music.core.MyList;
import com.mo.music.domain.Singer;
import com.mo.music.domain.SingerApply;
import com.mo.music.domain.SingerApplyDao;
import com.mo.music.domain.UserDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * SingerApplyService
 */
@Service
public class SingerApplyService {

    @Autowired
    private SingerApplyDao singerApplyDao;

    @Autowired
    private SingerService singerService;

    @Autowired
    private UserDao userDao;

    /**
     * 新增审核提交
     * @param userId
     * @param intro
     * @param singerName
     * @param singerAvatar
     */
    public void insertSingerApply(BigInteger userId, String intro, String singerName, String singerAvatar) {
        SingerApply singerApply = singerApplyDao.queryApply(userId);
        if (singerApply != null) {
            throw new MyException("审核中,请勿重复发起", 400);
        }
        if (intro == null || intro.equals("")) {
            throw new MyException("申请信息不可为空", 400);
        }
        if (singerName == null || singerName.equals("")) {
            throw new MyException("歌手艺名不可为空", 400);
        }
        if (singerAvatar == null || singerAvatar.equals("")) {
            throw new MyException("请上传头像", 400);
        }
        singerApply = new SingerApply();
        singerApply.setIntro(intro);
        singerApply.setUserId(userId);
        singerApply.setSingerAvatar(singerAvatar);
        singerApply.setSingerName(singerName);
        Timestamp current  = new Timestamp(System.currentTimeMillis());
        singerApply.setGmtCreate(current);
        singerApply.setGmtModified(current);
        singerApply.setStatus(0);
        singerApplyDao.insertSingerApply(singerApply);
    }

    /** 查询单个 */
    public SingerApply queryUserApplyStatus(BigInteger userId) {
        return singerApplyDao.queryApply(userId);
    }

    /**  更新状态 */
    @Transactional
    public void updateSingerApply(BigInteger userId, int status, String apply) {
        if (status !=0 && status != 1 && status != 2) {
            throw new MyException("状态码不对", 400);
        }
        Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
        if (status == 2) {
            // 审核被拒绝
            if (apply == null || apply.equals("")) {
                throw new MyException("回复必须填写", 400);
            }
            singerApplyDao.updateStatus(userId, apply, status, gmtModified);
        } else if (status == 1) {
            // 审核已通过
            singerApplyDao.updateStatus(userId, apply, status, gmtModified);
            SingerApply singerApply = singerApplyDao.queryApply(userId);
            Singer singer  = new Singer();
            singer.setSingerAvatar(singerApply.getSingerAvatar());
            singer.setSingerName(singerApply.getSingerName());
            singerService.insertSinger(singer);
            userDao.updateUserSinger(userId, singer.getId());
        }
    }

    /**
     * 查询审核提交
     * @param status
     * @param pageNum
     * @param pageSize
     * @return
     */
    public MyList<SingerApply> queryApplyList(int status, int pageNum, int pageSize) {
        if (pageNum < 1) {
            throw new MyException("请检查页码", 400);
        }
        int limit = pageSize;
        int offset = (pageNum - 1) * pageSize;
        List<SingerApply> list = singerApplyDao.queryAllList(status, limit, offset);
        int total = singerApplyDao.countAllApply(status);
        return new MyList<>(list, total, pageNum, pageSize);
    }

    /**
     * 重新提出申请
     * @param userId
     * @param singerName
     * @param singerAvatar
     * @param intro
     */
    public void updateSingerApplyIntro(BigInteger userId, String singerName, String singerAvatar, String intro) {
        if (intro == null || intro.equals("")) {
            throw new MyException("申请信息不可为空", 400);
        }
        if (singerName == null || singerName.equals("")) {
            throw new MyException("歌手艺名不可为空", 400);
        }
        if (singerAvatar == null || singerAvatar.equals("")) {
            throw new MyException("请上传头像", 400);
        }
        SingerApply singerApply = singerApplyDao.queryApply(userId);
        singerApply.setIntro(intro);
        singerApply.setSingerAvatar(singerAvatar);  
        singerApply.setSingerName(singerName);
        singerApply.setStatus(0);
        Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
        singerApply.setGmtModified(gmtModified);
        singerApplyDao.updateIntro(singerApply);
    }
}