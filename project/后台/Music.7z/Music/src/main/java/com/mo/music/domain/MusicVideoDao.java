package com.mo.music.domain;

import java.math.BigInteger;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

/**
 * MusicVideoDao
 */
@Mapper
public interface MusicVideoDao {

    /**
     * 新增
     * @param musicVideo
     */
    @Insert("INSERT INTO music_video (mv_name, mv_author, mv_cover, mv_url, music_id, gmt_create, gmt_modified, mv_visited, status) VALUES (#{mvName}, #{mvAuthor}, #{mvCover}, #{mvUrl}, #{musicId}, #{gmtCreate}, #{gmtModified}, #{mvVisited}, #{status})")
    @SelectKey(statement="SELECT LAST_INSERT_ID()" ,keyProperty="id", before=false, resultType=java.math.BigInteger.class)
    void insertMV(MusicVideo musicVideo);

    /**
     * 查询单个
     * @param id
     * @return
     */
    @Select("SELECT id, mv_name, mv_author, mv_url, mv_cover, music_id, gmt_create, gmt_modified, mv_visited, status FROM music_video WHERE id=#{id}")
    MusicVideo queryMusicVideo(@Param("id") BigInteger id);


    /** 查询全部 */
    @Select("SELECT id, mv_name, mv_author, mv_url, mv_cover, music_id, gmt_create, gmt_modified, mv_visited, status FROM music_video LIMIT #{limit} OFFSET #{offset}")
    List<MusicVideo> queryMusicVideoList(@Param("limit") int limit, @Param("offset") int offset);

    @Select("SELECT COUNT(id) FROM music_video ")
    Integer countMusicVideo();
    /**
     * 按状态查询列表
     * @param status
     * @param limit
     * @param offset
     * @return
     */
    @Select("SELECT id, mv_name, mv_author, mv_url, mv_cover, music_id, gmt_create, gmt_modified, mv_visited, status FROM music_video WHERE status=#{status} LIMIT #{limit} OFFSET #{offset}")
    List<MusicVideo> queryMusicVideoListByStatus(@Param("status") int status, @Param("limit") int limit, @Param("offset") int offset);

    @Select("SELECT COUNT(id) FROM music_video  WHERE status=#{status} ")
    Integer countMusicVideoListByStatus(@Param("status") int status);
    /**
     * 更改状态
     * @param id
     * @param status
     */
    @Update("UPDATE music_video SET status=#{status} WHERE id=#{id}")
    void updateStatus(@Param("id") BigInteger id, @Param("status") int status);

    /**
     * 更改内容
     * @param musicVideo
     */
    @Update("UPDATE music_video SET mv_name=#{mvName}, mv_author=#{mvAuthor}, mv_url=#{mv_url}, mv_cover=#{mvCover}, music_id=#{musicId}, gmt_modified=#{gmtModified} WHERE id=#{id}")
    void updateInfo(MusicVideo musicVideo);


}