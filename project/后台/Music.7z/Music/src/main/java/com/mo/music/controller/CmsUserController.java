package com.mo.music.controller;

import java.math.BigInteger;

import com.mo.music.core.MyList;
import com.mo.music.core.MyResult;
import com.mo.music.domain.SingerApply;
import com.mo.music.domain.User;
import com.mo.music.service.SingerApplyService;
import com.mo.music.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * CmsUserController
 */
@RestController
@RequestMapping("/cms/user")
public class CmsUserController {

	@Autowired
	private UserService userService;

	@Autowired
	private SingerApplyService singerApplyService;

	@RequestMapping(value = "/list", method = RequestMethod.POST)
	public MyResult<MyList<User>> getUserList(String name, @RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(defaultValue = "10") Integer pageSize) {
		MyList<User> list = userService.queryAllUserByUserName(name, pageNum, pageSize);
		MyResult<MyList<User>> myResult = new MyResult<>();
		myResult.setData(list);
		return myResult;
	}

	/**
	 * 审核列表
	 * @param status
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/checkingList", method = RequestMethod.POST) 
	public MyResult<MyList<SingerApply>> getCheckingUserList(@RequestParam(defaultValue = "0") Integer status, @RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(defaultValue = "10") Integer pageSize) {
		MyList<SingerApply> list = singerApplyService.queryApplyList(status, pageNum, pageSize);
		MyResult<MyList<SingerApply>> myResult = new MyResult<>();
		myResult.setData(list);
		return myResult;
	}

	/**	通过 */
	@RequestMapping(value = "/passApply", method = RequestMethod.POST)
	public MyResult<?> passApply(BigInteger userId, String apply) {
		singerApplyService.updateSingerApply(userId, 1, apply);
		return new MyResult<>();
	}

	/**
	 * 拒绝
	 * @param userId
	 * @param apply
	 * @return
	 */
	@RequestMapping(value = "/refuseApply", method = RequestMethod.POST)
	public MyResult<?> refuseApply(BigInteger userId, String apply) {
		singerApplyService.updateSingerApply(userId, 2, apply);
		return new MyResult<>();
	}
}