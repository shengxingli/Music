package com.mo.music.domain;

import java.math.BigInteger;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * AlbumMusicDao
 */
@Mapper
public interface AlbumMusicDao {

    /**
     * 查询专辑内的音乐
     * @param albumId
     * @return
     */
    @Select("SELECT music_id, music_name, singer_id, singer_name from album_music WHERE album_id=#{albumId}")
    List<AlbumMusic> queryAlbumMusicByAlbumId(@Param("albumId") BigInteger albumId);

	@Select("SELECT id FROM album_music WHERE music_id=#{musicId} AND album_id=#{albumId}")
	AlbumMusic queryAlbumMusic(@Param("musicId") BigInteger musicId, @Param("albumId") BigInteger albumId);

    /**
     * 往某个专辑内新增音乐
     * @param albumMusic
     */
    @Insert("INSERT INTO album_music (music_id, music_name, album_id, singer_id, singer_name, gmt_create,gmt_modified) VALUES (#{musicId}, #{musicName}, #{albumId}, #{singerId}, #{singerName}, #{gmtCreate}, #{gmtModified})")
    void insertAlbumMusic(AlbumMusic albumMusic);

    /**
     * 删除专辑内的某个音乐
     * @param musicId
     * @param albumId
     */
    @Delete("DELETE FROM album_music WHERE music_id=#{musicId} AND album_id=#{albumId}")
    void removeAlbumMusic(@Param("musicId") BigInteger musicId, @Param("albumId") BigInteger albumId);
}