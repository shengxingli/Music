package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * LyricDao
 */
@Mapper
public interface LyricDao {

	/**
	 * 通过音乐Id查询歌词
	 * @param musicId
	 * @return
	 */
	@Select("SELECT lyric FROM lyric WHERE music_id = #{musicId}")
	String queryMysicLyric(@Param("musicId") BigInteger musicId);
	
	@Select("SELECT music_id, lyric, gmt_create, gmt_modified FROM lyric LIMIT #{limit} OFFSET #{offset}")
	List<Lyric> queryAllLyric(@Param("limit") int limit, @Param("offset") int offset);

	@Select("SELECT COUNT(id) FROM lyric")
	Integer countAllLyric();

	/**
	 * 通过id修改歌词
	 * @param id
	 * @param lyric
	 * @param gmtModified
	 * @return
	 */
	@Update("UPDATE lyric SET lyric=#{lyric}, gmt_modified=#{gmtModified} WHERE music_id=#{musicId}")
	void updateMysicLyric(@Param("musicId") BigInteger musicId, @Param("lyric") String lyric, @Param("gmtModified") Timestamp gmtModified );

	/**
	 * 通过id删除歌词
	 * @param id
	 * @return
	 */
	@Delete("DELETE FROM lyric WHERE id = #{id}")
	void removeLyric(@Param("id") BigInteger id);

	/**
	 * 新增歌词
	 * @param musicId
	 * @param lyric
	 * @param gmtCreate
	 * @param gmtModified
	 */
	@Insert("INSERT INTO lyric (music_id, lyric, gmt_create, gmt_modified) VALUES (#{musicId}, #{lyric}, #{gmtCreate}, #{gmtModified})")
	void insertMysicLyric(Lyric lyric);

}