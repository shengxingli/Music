package com.mo.music.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import com.mo.music.core.MyException;
import com.mo.music.core.MyList;
import com.mo.music.domain.Music;
import com.mo.music.domain.MusicDao;
import com.mo.music.domain.SingerDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * MusicService
 */
@Service
public class MusicService {
	@Autowired
	private MusicDao musicDao;

	@Autowired
	private SingerDao singerDao;
	/**
	 * 通过ID查询音乐,访问数量+1
	 * 
	 * @param id 音乐id
	 * @return Music
	 */
	public Music queryMusicById(BigInteger id) {
		Music music = musicDao.queryMusicById(id);
		if (music != null && music.getIsOnline() == 1) {
			musicDao.increaseCountVisited(id);
			return music;
		} else {
			throw new MyException("请检查ID", 403);
		}
	}

	/**
	 * 通过ID查询音乐,不限状态,访问数量+1
	 * 
	 * @param id 音乐id
	 * @return Music
	 */
	public Music queryMusicById(BigInteger id, Boolean isAnyStatus) {
		Music music = musicDao.queryMusicById(id);
		if (music != null &&  (music.getIsOnline() == 1 || (music.getIsOnline() == 0 && isAnyStatus))) {
			musicDao.increaseCountVisited(id);
			return music;
		} else {
			throw new MyException("请检查ID", 403);
		}
	}


	/**
	 * 查询某个歌手最受欢迎的音乐
	 * @param singerId
	 * @return
	 */
	public List<Music> queryHotMusicBySingerId(BigInteger singerId) {
		return musicDao.queryHotMusicBySingerId(singerId);
	}

	/**
	 * 通过名称查询音乐列表
	 * 
	 * @param name 音乐名称
	 * @return MyList<Music>
	 */
	public MyList<Music> queryMusicByMusicName(String name, int pageNum, int pageSize) {
		int total = musicDao.countMusicNumberByMusicName(name);
		return new MyList<Music>(musicDao.queryMusicByMusicName(name, pageSize, (pageNum - 1) * pageSize), total, pageNum, pageSize);
	}

	/**
	 * 通过歌手名称查询音乐列表
	 * @param name
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	public MyList<Music> queryMusicBySingerName(String name, int pageNum, int pageSize) {
		int total = musicDao.countMusicNumberBySingerName(name);
		return new MyList<Music>(musicDao.queryMusicBySingerName(name, pageSize, (pageNum - 1) * pageSize), total, pageNum, pageSize);
	}
	
	public MyList<Music> queryMusicBySingerId(BigInteger id, int pageNum, int pageSize) {
		if (pageNum < 1) {
			throw new MyException("页码不正确", 400);
		}
		int total = musicDao.countMusicBySingerId(id);
		int limit = pageSize;
		int offset = (pageNum - 1) * pageSize;
		List<Music> list = musicDao.queryMusicBySingerId(id, limit, offset);
		return new MyList<Music>(list, total, pageNum, pageSize);
	}

	/**
	 * 启禁用音乐
	 * @param id
	 * @return
	 */
	public void ableMusicById(BigInteger id, int status) {
		if (status < 0 || status > 1) {
			throw new MyException("状态值不正确", 400);
		}
		Music music = new Music();
		music.setGmtModified(new Timestamp(System.currentTimeMillis()));
		music.setIsOnline(status);
		music.setId(new BigInteger(id.toString()));
		musicDao.updateMusicOnline(music);
	}

	/**
	 * 创建新音乐
	 * @param music
	 */
	public void createMusic(Music music) {
		if (music.getMusicName() == null) {
			throw new MyException("名称不能为空", 400);
		}
		if (music.getMusicSingerId() == null) {
			throw new MyException("歌手不能为空", 400);
		}
		if (music.getMusicUrl() == null) {
			throw new MyException("地址不能为空", 400);
		}
		Timestamp gmtCreate = new Timestamp(System.currentTimeMillis());
		Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
		music.setId(null);
		music.setGmtCreate(gmtCreate);
		music.setGmtModified(gmtModified);
		if (music.getIsOnline() == null) {
			music.setIsOnline(1);
		}
		singerDao.increaseSingerMusicCount(music.getMusicSingerId());
		musicDao.insertMusic(music);
	}
	
	// 编辑音乐
	public void editMusic(Music music) {
		Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
		music.setGmtModified(gmtModified);
		if (null == music.getIsOnline()) {
			throw new MyException("缺少歌曲状态", 400);
		}
		musicDao.updateMusic(music);
	}
}