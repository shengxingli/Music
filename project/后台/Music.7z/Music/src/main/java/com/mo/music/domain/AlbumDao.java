package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

/**
 * AlbumDao
 */
@Mapper
public interface AlbumDao {

	/**
	 * 插入一个新专辑
	 * @param album
	 */
	@Insert("INSERT INTO album (album_name, singer_name, singer_id, count_music, gmt_create, gmt_modified) VALUES (#{albumName}, #{singerName}, #{singerId}, #{countMusic}, #{gmtCreate}, #{gmtModified})")
	@SelectKey(statement="SELECT LAST_INSERT_ID()" ,keyProperty="id", before=false, resultType=java.math.BigInteger.class)
	void insertAlbum(Album album);

	/**
	 * 更新专辑,只允许更新专辑名称/歌手信息
	 * @param album
	 */
	@Update("UPDATE album SET album_name=#{albumName}, gmt_modified=#{gmtModified},  singer_name=#{singerName}, singer_id=#{singerId} WHERE id=#{id}")
	void updateAlbum(Album album);

	/**
	 * 加一专辑内歌曲数量
	 * @param id
	 */
	@Update("UPDATE album SET count_music=count_music+1, gmt_modified=#{gmtModified} WHERE id=#{id}")
	void increaseAlbumMusicCount(@Param("id") BigInteger id, @Param("gmtModified") Timestamp gmtModified);

	/**
	 * 减一专辑内歌曲数量
	 * @param id
	 */
	@Update("UPDATE album SET count_music=count_music-1, gmt_modified=#{gmtModified} WHERE id=#{id}")
	void reduceAlbumMusicCount(@Param("id") BigInteger id, @Param("gmtModified") Timestamp gmtModified);

	/**
	 * 下架专辑
	 * @param id
	 * @param status
	 */
	@Update("UPDATE album SET status=#{status}, gmt_modified=#{gmtModified} WHERE id=#{id}")
	void updateAlbumStatus(@Param("id") BigInteger id, @Param("status") Integer status, Timestamp gmtModified);
	
	/**
	 * 通过id查询专辑
	 * @param id
	 * @return
	 */
	@Select("SELECT id, album_name, singer_name, singer_id, count_music, status FROM album WHERE id=#{id}")
	Album queryAlbumById(@Param("id") BigInteger id);
	
	/**
	 * 查询某歌手的全部专辑
	 * @param singerId
	 * @return
	 */
	@Select("SELECT id, album_name, singer_name, singer_id, count_music, status, gmt_create, gmt_modified FROM album WHERE singer_id=#{singerId} AND status=1")
	List<Album> queryAllAlbumBySingerId(@Param("singerId") BigInteger singerId);
	
	@Select("SELECT id, album_name, singer_name, singer_id, count_music, status, gmt_create, gmt_modified FROM album WHERE album_name LIKE CONCAT('%%', #{name} ,'%%') LIMIT #{limit} OFFSET #{offset}")
	List<Album> queryAllAlbum(@Param("name") String name, @Param("limit") int limit, @Param("offset") int offset );
	
	@Select("SELECT COUNT(id) FROM album WHERE album_name LIKE CONCAT('%%', #{name} ,'%%')")
	Integer countAlbumNumber(@Param("name") String name);
}