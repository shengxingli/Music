package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

public class Singer {
    /** 主键 */
    private BigInteger id;

	/** 名字 */
	private String singerName;

	/** 头像 */
	private String singerAvatar;

	/** 入驻状态, 0为隐藏状态, 1为入驻展示, 2为待审核 */
	private Integer status;

	/** 专辑数量 */
	private Integer countAlbum;

	/** 歌曲数量 */
	private Integer countMusic;

	/** 最热歌曲 */
	private List<Music> hotSong;

	private Timestamp gmtCreate;

	private Timestamp gmtModified;

	/**
	 * @return the singerName
	 */
	public String getSingerName() {
		return singerName;
	}

	/**
	 * @return the id
	 */
	public BigInteger getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(BigInteger id) {
		this.id = id;
	}

	/**
	 * @param singerName the singerName to set
	 */
    public void setSingerName(String singerName) {
        this.singerName = singerName;
    }

	public String getSingerAvatar() {
		return singerAvatar;
	}

	public void setSingerAvatar(String singerAvatar) {
		this.singerAvatar = singerAvatar;
	}

	public Integer getCountAlbum() {
		return countAlbum;
	}

	public void setCountAlbum(Integer countAlbum) {
		this.countAlbum = countAlbum;
	}

	public List<Music> getHotSong() {
		return hotSong;
	}

	public void setHotSong(List<Music> hotSong) {
		this.hotSong = hotSong;
	}

	public Integer getCountMusic() {
		return countMusic;
	}

	public void setCountMusic(Integer countMusic) {
		this.countMusic = countMusic;
	}

	public Timestamp getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Timestamp gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Timestamp getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Timestamp gmtModified) {
		this.gmtModified = gmtModified;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
}