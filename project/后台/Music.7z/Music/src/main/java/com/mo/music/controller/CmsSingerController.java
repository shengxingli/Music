package com.mo.music.controller;

import java.math.BigInteger;

import com.mo.music.core.MyException;
import com.mo.music.core.MyList;
import com.mo.music.core.MyResult;
import com.mo.music.domain.Singer;
import com.mo.music.service.SingerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



/**
 * CmsSingerController
 */
@RestController
@RequestMapping("/cms/singer")
public class CmsSingerController {

	@Autowired
	private SingerService singerService;
	
	@RequestMapping(value="/list", method=RequestMethod.POST)
	public MyResult<MyList<Singer>> queryAllSinger(@RequestParam(defaultValue = "") String name, @RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(defaultValue = "10") Integer pageSize) {
		MyList<Singer> list = singerService.queryAllSinger(name, pageNum, pageSize);
		MyResult<MyList<Singer>> myResult = new MyResult<MyList<Singer>>();
		myResult.setData(list);
		return myResult;
	}
	

	@RequestMapping(value="/edit", method=RequestMethod.POST)
	public MyResult<?> editSingerInfo(Singer singer) {
		if (singer.getId() == null) {
			singerService.insertSinger(singer);
		} else {
			throw new MyException("id值须为空", 400);
		}
		return new MyResult<>();
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public MyResult<?> updateSingerName(BigInteger id, String name, String avatar) {
		singerService.updateSingerName(id, name, avatar);
		return new MyResult<>();
	}

	@RequestMapping(value = "/enable", method = RequestMethod.POST)
	public MyResult<?> enableSinger(BigInteger id) {
		singerService.updateSingerEntering(id);
		return new MyResult<>();
	}

	@RequestMapping(value = "/disable", method = RequestMethod.POST)
	public MyResult<?> disableSinger(BigInteger id) {
		singerService.updateSingerOutEnter(id);
		return new MyResult<>();
	}
}