package com.mo.music.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import com.mo.music.core.MyException;
import com.mo.music.core.MyList;
import com.mo.music.domain.Album;
import com.mo.music.domain.AlbumDao;
import com.mo.music.domain.AlbumMusic;
import com.mo.music.domain.AlbumMusicDao;
import com.mo.music.domain.Music;
import com.mo.music.domain.MusicDao;
import com.mo.music.domain.Singer;
import com.mo.music.domain.SingerDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AlbumService
 */
@Service
public class AlbumService {

    @Autowired
    private AlbumDao albumDao;

    @Autowired
    private AlbumMusicDao albumMusicDao;

    @Autowired
    private MusicDao musicDao;

    @Autowired 
    private SingerDao singerDao;

    /**
     * 新建专辑
     * @param album
     */
    @Transactional
    public void insertAlbum(Album album) {
        if (album.getAlbumName() == null || album.getAlbumName().equals("")) {
            throw new MyException("请输入专辑名称", 400);
        }
        if (album.getSingerId() == null) {
            throw new MyException("请输入歌手ID", 400);
        }
        Singer singer;
        try {
            singer = singerDao.querySingerById(album.getSingerId());
            if (singer != null) {
                album.setSingerName(singer.getSingerName());
                Timestamp nowDate = new Timestamp(System.currentTimeMillis());
                album.setGmtCreate(nowDate);
                album.setGmtModified(nowDate);
                album.setCountMusic(0);
                if (album.getStatus() == null || (album.getStatus() != 0 && album.getStatus() != 1)) {
                    album.setStatus(1);
                }
                albumDao.insertAlbum(album);
                singerDao.increaseSingerAlbumCount(singer.getId());
            }
        } catch (Exception e) {
            throw new MyException("未找到该歌手信息", 400);
        }
    }

    /**
     * 往专辑内插入音乐
     * @param albumMusic
     */
    @Transactional
    public void insertMusicIntoAlbum(BigInteger albumId, BigInteger musicId) {
        AlbumMusic albumMusic = new AlbumMusic();
        Music music;
        Album album;
        try {
            music = musicDao.queryMusicById(musicId);
            album = albumDao.queryAlbumById(albumId);
        } catch (Exception e) {
            throw new MyException("歌曲或专辑不存在", 400);
		}
		if (albumMusicDao.queryAlbumMusic(musicId, albumId) != null) {
			throw new MyException("该专辑内已有该歌曲", 400);
		}
        albumMusic.setAlbumId(albumId);
        albumMusic.setMusicId(musicId);
        albumMusic.setMusicName(music.getMusicName());
        albumMusic.setSingerId(music.getMusicSingerId());
        albumMusic.setSingerName(music.getMusicSingerName());
        Timestamp current = new Timestamp(System.currentTimeMillis());
        albumMusic.setGmtCreate(current);
        albumMusic.setGmtModified(current);
        albumMusicDao.insertAlbumMusic(albumMusic);
		if (music.getMusicAlbum() == null || music.getMusicAlbumId() == null || music.getMusicAlbum().equals(album.getAlbumName()) || music.getMusicAlbumId().compareTo(album.getId()) != 0 ) {
			increaseAlbumMusicCount(albumMusic.getAlbumId());
			music.setMusicAlbum(album.getAlbumName());
			music.setMusicAlbumId(album.getId());
			musicDao.updateMusic(music);
		}
    }

    /**
     * 移除专辑中的某个歌曲
     * @param albumId
     * @param musicId
     */
    @Transactional
    public void removeAlbumMusic(BigInteger albumId, BigInteger musicId) {
        Music music;
        Album album;
        music = musicDao.queryMusicById(musicId);
        album = albumDao.queryAlbumById(albumId);
        if (album == null || music == null) {
            throw new MyException("歌曲或专辑不存在", 400);
        }
        albumMusicDao.removeAlbumMusic(musicId, albumId);
        reduceAlbumMusicCount(albumId);
        music.setMusicAlbum(null);
        music.setMusicAlbumId(null);
        musicDao.updateMusic(music);
    }

    /**
     * 启禁用专辑
     * @param id
     * @param status
     */
    public void ableAlbumById(BigInteger id, Integer status) {
        if (status != 0 && status != 1) {
            throw new MyException("状态不正确", 400);
        }
        Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
        albumDao.updateAlbumStatus(id, status, gmtModified);
    }

    /**
     * 更新专辑信息,只允许更新歌手信息和专辑名称
     * @param album
     */
    public void updateAlbum(Album album) {
        Timestamp nowTimestamp = new Timestamp(System.currentTimeMillis());
        if (album.getSingerId() != null) {
            Singer singer = singerDao.querySingerById(album.getSingerId());
            if (singer != null) {
                album.setSingerName(singer.getSingerName());
            } else {
                throw new MyException("未找到该歌手", 400);
            }
        }
        album.setGmtModified(nowTimestamp);
        albumDao.updateAlbum(album);
    }

    /**
     * 查询单个专辑的信息
     * @param id
     * @return
     */
    public Album queryAlbumById(BigInteger id) {
		Album album =  albumDao.queryAlbumById(id);
		if (album == null) {
			throw new MyException("该专辑不存在", 400);
		}
        List<AlbumMusic> listMusic = albumMusicDao.queryAlbumMusicByAlbumId(id);
        album.setListMusic(listMusic);
        return album;
    }

    /**
     * 查询歌手的全部专辑信息
     * @param id
     * @return
     */
    public List<Album> querySingerAlbumBySingerId(BigInteger id) {
        return albumDao.queryAllAlbumBySingerId(id);
    }
    
    /**
     * 查询全部专辑
     * @param pageNum
     * @param pageSize
     * @return
     */
    public MyList<Album> queryAllAlbum(String name, int pageNum, int pageSize) {
		if (name == null) {
			name = "";
		}
        if (pageNum < 1) {
            throw new MyException("页码不正确", 400);
        }
        int offset = pageSize * (pageNum - 1);
		List<Album> list = albumDao.queryAllAlbum(name, pageSize, offset);
		int total = albumDao.countAlbumNumber(name);
		MyList<Album> myList = new MyList<>(list, total, pageNum, pageSize);
		return myList;
    }

    /**
     * 专辑内歌曲数量加一
     * @param id
     */
    public void increaseAlbumMusicCount(BigInteger id) {
        Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
        try {
            albumDao.increaseAlbumMusicCount(id, gmtModified); 
        } catch (Exception e) {
            throw new MyException("id有误", 400);
        }
    }

    /**
     * 专辑内歌曲数量减一
     * @param id
     */
    public void reduceAlbumMusicCount(BigInteger id) {
        Album album;
        try {
            album = albumDao.queryAlbumById(id);
        } catch (Exception e) {
            throw new MyException("id有误", 400);
        }
        if (album.getCountMusic() == 0) {
            throw new MyException("歌曲数量已为0", 400);
        }
        Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
        albumDao.reduceAlbumMusicCount(id, gmtModified);
    }
}