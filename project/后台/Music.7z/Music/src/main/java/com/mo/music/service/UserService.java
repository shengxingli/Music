package com.mo.music.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import com.mo.music.core.JWTToken;
import com.mo.music.core.MyException;
import com.mo.music.core.MyList;
import com.mo.music.core.RSAUtils;
import com.mo.music.domain.Password;
import com.mo.music.domain.PasswordDao;
import com.mo.music.domain.User;
import com.mo.music.domain.UserDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * UserService
 */
@Service
public class UserService {

	@Autowired
	private UserDao userDao;

	@Autowired
	private PasswordDao passwordDao;

	/**
	 * 查询单个用户
	 * @param id
	 * @return
	 */
	public User queryUserById(BigInteger id) {
		if (id == null) {
			throw new MyException("id不可为空", 400);
		}
		return userDao.queryUserById(id);
	}

	/**
	 * 创建用户
	 * @param userName
	 * @param psd
	 * @return
	 */
	@Transactional
	public String insertUser(String userName, String psd) {
		User user =  userDao.queryUserByUserName(userName);
		if (user != null) {
			throw new MyException("该帐号已存在", 400);
		}
		Timestamp gmtCreate = new Timestamp(System.currentTimeMillis());
		Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
		user = new User();
		user.setUserName(userName);
		user.setGmtCreate(gmtCreate);
		user.setGmtModified(gmtModified);
		userDao.insertUser(user);
		BigInteger id = user.getId();
		Password password = new Password();
		password.setUserId(id);
		password.setPassword(psd);
		password.setGmtCreate(gmtCreate);
		password.setGmtModified(gmtModified);
		password.setUserName(userName);
		passwordDao.insertUserPassword(password);
		return JWTToken.getToken(id, psd);
	}

	/**
	 * 登录
	 * @param id
	 * @param password
	 * @return
	 */
	public String loginById(BigInteger id, String password) {
		String dbPs = passwordDao.queryUserPasswordById(id);
		if (dbPs == null) {
			throw new MyException("该用户不存在", 403);
		}
		String dbDeco = RSAUtils.decode(dbPs);
		String iptDeco = RSAUtils.decode(password);
		if (dbDeco.equals(iptDeco)) {
			return JWTToken.getToken(id, password);
		} else {
			throw new MyException("密码错误", 400);
		}
	}

	/**
	 * 登录
	 * @param userName
	 * @param password
	 * @return
	 */
	public String loginByUserName(String userName, String password) {
		User user = userDao.queryUserByUserName(userName);
		if (user == null || user.getId() == null || user.getUserName() == null) {
			throw new MyException("该用户不存在", 403);
		}
		String dbPs = passwordDao.queryUserPasswordById(user.getId());
		String dbDeco = RSAUtils.decode(dbPs);
		String iptDeco = RSAUtils.decode(password);
		if (dbDeco.equals(iptDeco)) {
			return JWTToken.getToken(user.getId(), password);
		} else {
			throw new MyException("密码错误", 400);
		}
	}

	/**	查询用户密码 */
	public String queryUserPassword(BigInteger id) {
		return passwordDao.queryUserPasswordById(id);
	}

	/**
	 * 查询所有用户
	 * @param name
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	public MyList<User> queryAllUserByUserName(String name, int pageNum, int pageSize) {
		if (pageNum < 0) {
			throw new MyException("页码不正确", 400);
		}
		int limit = pageSize;
		int offset = (pageNum - 1) * pageSize;
		List<User> list = userDao.queryAllUserByName(name, limit, offset);
		int total = userDao.countUserByName(name);
		return new MyList<>(list, total, pageNum, pageSize);
	}

	/** 更新用户信息 */
	public void updateUser(User user) {
		Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
		user.setGmtModified(gmtModified);
		userDao.updateUserInfo(user);
	}
}