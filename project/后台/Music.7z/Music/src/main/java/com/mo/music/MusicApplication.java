package com.mo.music;


import com.mo.music.core.RSAUtils;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicApplication {

    public static void main(String[] args) {
		System.out.println(RSAUtils.encode("123456"));
        SpringApplication.run(MusicApplication.class, args);
    }
}
