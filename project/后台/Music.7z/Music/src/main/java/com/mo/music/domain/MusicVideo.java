package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;

/**
 * MusicVideo
 */
public class MusicVideo {

    private BigInteger id;

    private String mvName;

    private String mvAuthor;

    private String mvCover;

    private String mvUrl;

    private BigInteger musicId;

    private Integer status;

    private Integer mvVisited;

    private Timestamp gmtCreate;

    private Timestamp gmtModified;

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public String getMvName() {
        return mvName;
    }

    public void setMvName(String mvName) {
        this.mvName = mvName;
    }

    public String getMvAuthor() {
        return mvAuthor;
    }

    public void setMvAuthor(String mvAuthor) {
        this.mvAuthor = mvAuthor;
    }

    public String getMvUrl() {
        return mvUrl;
    }

    public void setMvUrl(String mvUrl) {
        this.mvUrl = mvUrl;
    }

    public BigInteger getMusicId() {
        return musicId;
    }

    public void setMusicId(BigInteger musicId) {
        this.musicId = musicId;
    }

    public Timestamp getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Timestamp gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Timestamp getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Timestamp gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getMvCover() {
        return mvCover;
    }

    public void setMvCover(String mvCover) {
        this.mvCover = mvCover;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getMvVisited() {
        return mvVisited;
    }

    public void setMvVisited(Integer mvVisited) {
        this.mvVisited = mvVisited;
    }
}