package com.mo.music.controller;

import java.math.BigInteger;

import com.mo.music.core.MyList;
import com.mo.music.core.MyResult;
import com.mo.music.domain.Music;
import com.mo.music.service.MusicService;
import com.mo.music.service.LyricService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


/**
 * MusicController
 */
@RestController
@RequestMapping("/music")
public class MusicController {

	@Autowired
	private MusicService musicService;

	@Autowired
	private LyricService lyricService;

	/**
	 * 通过歌曲ID获取歌曲详情
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/info", method = RequestMethod.POST)
	public MyResult<Music> queryMusicInfo(BigInteger id) {
		MyResult<Music> myResult = new MyResult<Music>();
		myResult.setData(musicService.queryMusicById(id));
		return myResult;
	}

	/**
	 * 通过歌曲名称搜索歌曲
	 * @param name
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public MyResult<MyList<Music>> queryMusicByMusicName(@RequestParam(required = false) String name, @RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(defaultValue = "10") Integer pageSize) {
		MyResult<MyList<Music>> myResult = new MyResult<MyList<Music>>();
		myResult.setData(musicService.queryMusicByMusicName(name, pageNum, pageSize));
		return myResult;
	}
	
	/**
	 * 通过歌曲id查询对应歌词
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/lyric", method=RequestMethod.POST)
	public MyResult<String> getLyric(@RequestParam BigInteger id) {
		MyResult<String> myResult = new MyResult<>();
		String lyric = lyricService.queryMusicLyric(id);
		myResult.setData(lyric);
		return myResult;
	}
	
}