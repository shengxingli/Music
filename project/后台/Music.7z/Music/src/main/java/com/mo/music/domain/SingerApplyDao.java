package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * SingerApplyDao
 */
@Mapper
public interface SingerApplyDao {

    /**
     * 查询列表
     * @param status
     * @param limit
     * @param offset
     * @return
     */
    @Select("SELECT id, user_id, singer_name, singer_avatar, intro, apply, status, gmt_create, gmt_modified FROM apply_singer WHERE status=#{status} LIMIT #{limit} OFFSET #{offset} ")
    List<SingerApply> queryAllList(@Param("status") int status, @Param("limit") int limit, @Param("offset") int offset);

    @Select("SELECT COUNT(id) FROM apply_singer WHERE status=#{status}")
    Integer countAllApply(int status);

    /** 查询单个 */
    @Select("SELECT id, user_id, singer_name, singer_avatar, intro, apply, status, gmt_create, gmt_modified FROM apply_singer WHERE user_id=#{userId}")
    SingerApply queryApply(@Param("userId") BigInteger userId);

    /**
     * 更新审核状态
     * @param userId
     * @param apply
     * @param status
     */
    @Update("UPDATE apply_singer SET status=#{status}, apply=#{apply}, gmt_modified=#{gmtModified} WHERE user_id=#{userId}")
    void updateStatus(@Param("userId") BigInteger userId, @Param("apply") String apply, @Param("status") int status, @Param("gmtModified") Timestamp gmtModified);

    /** 更新提交申请 */
    @Update("UPDATE apply_singer SET singer_name=#{singerName}, singer_avatar=#{singerAvatar}, intro=#{intro}, status=#{status}, gmt_modified=#{gmtModified} WHERE user_id=#{userId}")
    void updateIntro(SingerApply singerApply);
    
    /**
     * 新增
     * @param singerApply
     */
    @Insert("INSERT INTO apply_singer (user_id, singer_name, singer_avatar, intro, status, gmt_create, gmt_modified) VALUES (#{userId}, #{singerName}, #{singerAvatar}, #{intro}, #{status} #{gmtCreate}, #{gmtModified})")
    void insertSingerApply(SingerApply singerApply);

}