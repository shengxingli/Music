package com.mo.music.domain;

import java.math.BigInteger;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * PasswordDao
 */
@Mapper
public interface PasswordDao {
	/**
	 * 通过id查询用户密码
	 * @param id
	 * @return
	 */
	@Select("SELECT password from password where user_id = #{id}")
	String queryUserPasswordById(@Param("id") BigInteger id);

	/**
	 * 通过名称查询密码
	 * @param userName
	 * @return 加密后的密码
	 */
	@Select("SELECT password from password where user_name = #{userName}")
	String queryUserPasswordByName(@Param("userName") String userName);

	/** 
	 * 插入新用户到密码表
	 * @param userId
	 * @param userName
	 * @param password
	 */
	@Insert("INSERT INTO password (user_id, user_name, password, gmt_create, gmt_modified) VALUES (#{userId}, #{userName}, #{password}, #{gmtCreate}, #{gmtModified})")
	void insertUserPassword(Password password);
}