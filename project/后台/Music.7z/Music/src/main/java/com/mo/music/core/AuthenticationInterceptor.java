package com.mo.music.core;

import java.lang.reflect.Method;
import java.math.BigInteger;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.mo.music.domain.User;
import com.mo.music.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 * AuthenticationInterceptor
 */
public class AuthenticationInterceptor implements HandlerInterceptor {

	@Autowired
	UserService userService;

	@Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object object) throws Exception {
        // 如果不是映射到方法直接通过
        if(!(object instanceof HandlerMethod)){
			return true;
		}
		if (httpServletRequest.getRequestURI().startsWith("/api/cms/")) {
			String sys_t = MyUtils.getRequestParam("sys_t", httpServletRequest);
			if (sys_t.equals("")) {
				throw new MyException("登录超时", 502);
			}
			// 验证 token
			Date issuedAt ;
			BigInteger id;
			try {
				id = new BigInteger(JWTToken.getAudience(sys_t).get(0));
			} catch (JWTDecodeException e) {
				throw new MyException("token错误", 400);
			}
			User user = userService.queryUserById(id);
			String password = RSAUtils.decode(userService.queryUserPassword(user.getId()));
			
			try {
				Algorithm algorithm = Algorithm.HMAC256(password);
				JWTVerifier verifier = JWT.require(algorithm)
					.withAudience(user.getId().toString())
					.build(); //Reusable verifier instance
				DecodedJWT jwt = verifier.verify(sys_t);
				issuedAt = jwt.getIssuedAt();
			} catch (JWTVerificationException exception){
				throw new MyException("用户信息错误", 401);
			}
			Date nowDate = new Date();
			int days = (int) ((nowDate.getTime() - issuedAt.getTime()) / (1000*3600*24));
			if (days > 7) {
				throw new MyException("登录超时", 502);
			}
		}
        HandlerMethod handlerMethod = (HandlerMethod) object;
        Method method = handlerMethod.getMethod();
        if (method.isAnnotationPresent(UserLoginToken.class)) {
            // getAnnotation, 返回注解类型
            UserLoginToken userLoginToken = method.getAnnotation(UserLoginToken.class);
            if (userLoginToken.required()) {
				String t = MyUtils.getRequestParam("t", httpServletRequest);
				if (t.equals("")) {
					throw new MyException("登录超时", 502);
				}
				// 验证 token
				Date issuedAt ;
				BigInteger id;
				try {
					id = new BigInteger(JWTToken.getAudience(t).get(0));
				} catch (JWTDecodeException e) {
					throw new MyException("token错误", 400);
				}
				User user = userService.queryUserById(id);
				String password = RSAUtils.decode(userService.queryUserPassword(user.getId()));
				
				try {
					Algorithm algorithm = Algorithm.HMAC256(password);
					JWTVerifier verifier = JWT.require(algorithm)
						.withAudience(user.getId().toString())
						.build(); //Reusable verifier instance
					DecodedJWT jwt = verifier.verify(t);
					issuedAt = jwt.getIssuedAt();
				} catch (JWTVerificationException exception){
					throw new MyException("用户信息错误", 401);
				}
				Date nowDate = new Date();
				int days = (int) ((nowDate.getTime() - issuedAt.getTime()) / (1000*3600*24));
				if (days > 7) {
					throw new MyException("登录超时", 502);
				}

            }
        }
	
        return true;
    }

	@Override
	public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o,
			ModelAndView modelAndView) throws Exception {
				int status = httpServletResponse.getStatus();
				if (status == 404) {
					System.out.println(404);
				} 
	}

	@Override
	public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			Object o, Exception e) throws Exception {
	}
}