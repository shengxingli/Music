package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

/**
 * Album
 */
public class Album {

	private BigInteger id;

	private String albumName;

	private String singerName;

	private BigInteger singerId;

	private Integer countMusic;

	private Integer status;
	
	private Timestamp gmtCreate;

	private Timestamp gmtModified;

	private List<AlbumMusic> listMusic;

	public BigInteger getId() {
		return id;
	}

	public void setId(BigInteger id) {
		this.id = id;
	}

	public String getAlbumName() {
		return albumName;
	}

	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}

	public Integer getCountMusic() {
		return countMusic;
	}

	public void setCountMusic(Integer countMusic) {
		this.countMusic = countMusic;
	}

	public Timestamp getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Timestamp gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	public Timestamp getGmtModified() {
		return gmtModified;
	}

	public void setGmtModified(Timestamp gmtModified) {
		this.gmtModified = gmtModified;
	}

	public String getSingerName() {
		return singerName;
	}

	public void setSingerName(String singerName) {
		this.singerName = singerName;
	}

	public BigInteger getSingerId() {
		return singerId;
	}

	public void setSingerId(BigInteger singerId) {
		this.singerId = singerId;
	}


	public List<AlbumMusic> getListMusic() {
		return listMusic;
	}

	public void setListMusic(List<AlbumMusic> listMusic) {
		this.listMusic = listMusic;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
}