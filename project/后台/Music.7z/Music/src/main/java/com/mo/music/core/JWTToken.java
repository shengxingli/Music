package com.mo.music.core;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

/**
 * GenerateToken
 */
public class JWTToken {

	public static String getToken(BigInteger id, String password) {
		String token = "";
		token = JWT.create()
				.withAudience(id.toString())
				.withIssuedAt(new Date())
				.sign(Algorithm.HMAC256((RSAUtils.decode(password))));
		return token;
	}

	public static List<String> getAudience(String t) {
		DecodedJWT jwt = JWT.decode(t);
		return jwt.getAudience();
	} 

}