package com.mo.music.controller;

import java.math.BigInteger;

import com.mo.music.core.MyResult;
import com.mo.music.domain.Album;
import com.mo.music.service.AlbumService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * AlbumController
 */
@RestController
@RequestMapping("/album")
public class AlbumController {

    @Autowired
    private AlbumService albumService;

    /**
     * 通过专辑id查询专辑详情
     * @param id
     * @return
     */
    @RequestMapping(value = "/info", method = RequestMethod.POST)
    public MyResult<Album> queryAlbumInfo(BigInteger id) {
        MyResult<Album> mResult = new MyResult<>();
        Album album = albumService.queryAlbumById(id);
        mResult.setData(album);
        return mResult;
    }
}