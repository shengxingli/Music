package com.mo.music.core;

import static org.apache.tomcat.util.codec.binary.Base64.decodeBase64;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.tomcat.util.codec.binary.Base64;
 
/**
* @author 作者:LYH
* @createDate 创建时间：2018年8月10日 上午11:18:21
*/
// @Configuration
public class RSAUtils {
    protected static final Log log = LogFactory.getLog(RSAUtils.class);
    private static String KEY_RSA_TYPE = "RSA";
    private static int KEY_SIZE = 1024;//JDK方式RSA加密最大只有1024位
    private static int ENCODE_PART_SIZE = KEY_SIZE/8;
    public static final String PUBLIC_KEY_NAME = "public";
    public static final String PRIVATE_KEY_NAME = "private";
    public static final String PUBLICK_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGkKOhc2XPML/tYrjQ0kqpKog7g2Cnx1u4tPUY75ShZOAaSmMlCI5s+u/8N7Pc1dNbIVYQXupNmFfWDUPRzZdA86tgUbodYY6bhlpk8r/GD+zCbox88Xh2kD93jKvODFgOeHre462VBh9V4/tzUZH+mHU2qsuPgUTZRM6ZuBV52QIDAQAB";
    public static final String PRIVATE_KEY = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIaQo6FzZc8wv+1iuNDSSqkqiDuDYKfHW7i09RjvlKFk4BpKYyUIjmz67/w3s9zV01shVhBe6k2YV9YNQ9HNl0Dzq2BRuh1hjpuGWmTyv8YP7MJujHzxeHaQP3eMq84MWA54et7jrZUGH1Xj+3NRkf6YdTaqy4+BRNlEzpm4FXnZAgMBAAECgYBkDsrNMzxhunML9ZtNEwEXFpwj/IVzXCaUimGxP/w5ogONKQDduaYF3PVziovASnKVUY1oMNtyBTRS4pwqNgAf4rWIptaan3gO1KlRmVY7SYkYpbL3IE2B+XSfCS42eFvG2lyTt70eW34g1/oQJ4voo32ZAOzAplTk0VrOZVLLAQJBANHYqGQrAfYgV0nNqtpsQ7uh022nAoX6DC3qmvIktsA7y5zBHCq9MPbKBuEj14lxWBPD68LWLacFsqTG24jhDvkCQQCkKUlDvmkx3yYFViCxwX6p5iG7EOB67L1BbUAXm7Du5N5zYGFMOjyFJwEHtml7sPa1U54t2viBzyzlcyClmRnhAkApXA+MdqGTVjp+FGhJVq9e6v1WDmXD7E28OxJBCZVvfBmckr8veUyOR7FlbIAN2eYnNyVfqIEk+02DhqI8b0dZAkBwjbYj8nuhrAQfiIvmFGrKBnV+EvY2kfa40zUsepz3ToiOxrgvUYaJLNLx/MmZ+x1L+cbsXcQhDHEV6LerkqtBAkBv9J3NESrSxIYWH0c3OynFWWdRvZkVyWqJrKda/uRT0zDO1AqVk+RQSqC3JnFiZXWfJ/jKBCVNYKDZ0EMJI4xp";

    /**
     * 创建公钥秘钥
     * @return
     */
    // @Bean(name = "rsaKeysMap")
    public static Map<String,String> createRSAKeys(){
        Map<String,String> keyPairMap = new HashMap<>();//里面存放公私秘钥的Base64位加密
        try {
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(KEY_RSA_TYPE);
            keyPairGenerator.initialize(KEY_SIZE,new SecureRandom());
            KeyPair keyPair = keyPairGenerator.generateKeyPair();
 
            //获取公钥秘钥
            String publicKeyValue = Base64.encodeBase64String(keyPair.getPublic().getEncoded());
            String privateKeyValue = Base64.encodeBase64String(keyPair.getPrivate().getEncoded());
 
            //存入公钥秘钥，以便以后获取
            keyPairMap.put(PUBLIC_KEY_NAME,publicKeyValue);
            keyPairMap.put(PRIVATE_KEY_NAME,privateKeyValue);

            System.out.println("==========public============");
            System.out.println(publicKeyValue);
            System.out.println("==========public============");
            System.out.println("==========private============");
            System.out.println(privateKeyValue);
            System.out.println("==========private============");
        } catch (NoSuchAlgorithmException e) {
            log.error("当前JDK版本没找到RSA加密算法！");
            e.printStackTrace();
        }
        return keyPairMap;
    }
 
    /**
     * 公钥加密
     * 描述：
     *     1字节 = 8位；
     *     最大加密长度如 1024位私钥时，最大加密长度为 128-11 = 117字节，不管多长数据，加密出来都是 128 字节长度。
     * @param sourceStr
     * @param publicKeyBase64Str
     * @return
     */
    public static String encode(String sourceStr){
        byte [] publicBytes = Base64.decodeBase64(PUBLICK_KEY);
        //公钥加密
        X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(publicBytes);
        List<byte[]> alreadyEncodeListData = new LinkedList<>();
 
        int maxEncodeSize = ENCODE_PART_SIZE - 11;
        String encodeBase64Result = null;
        try {
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_RSA_TYPE);
            PublicKey publicKey = keyFactory.generatePublic(x509EncodedKeySpec);
            Cipher cipher = Cipher.getInstance(KEY_RSA_TYPE);
            cipher.init(Cipher.ENCRYPT_MODE,publicKey);
            byte[] sourceBytes = sourceStr.getBytes("utf-8");
            int sourceLen = sourceBytes.length;
            for(int i=0;i<sourceLen;i+=maxEncodeSize){
                int curPosition = sourceLen - i;
                int tempLen = curPosition;
                if(curPosition > maxEncodeSize){
                    tempLen = maxEncodeSize;
                }
                byte[] tempBytes = new byte[tempLen];//待加密分段数据
                System.arraycopy(sourceBytes,i,tempBytes,0,tempLen);
                byte[] tempAlreadyEncodeData = cipher.doFinal(tempBytes);
                alreadyEncodeListData.add(tempAlreadyEncodeData);
            }
            int partLen = alreadyEncodeListData.size();//加密次数
 
            int allEncodeLen = partLen * ENCODE_PART_SIZE;
            byte[] encodeData = new byte[allEncodeLen];//存放所有RSA分段加密数据
            for (int i = 0; i < partLen; i++) {
                byte[] tempByteList = alreadyEncodeListData.get(i);
                System.arraycopy(tempByteList,0,encodeData,i*ENCODE_PART_SIZE,ENCODE_PART_SIZE);
            }
            encodeBase64Result = Base64.encodeBase64String(encodeData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return encodeBase64Result;
    }
 
    /**
     * 私钥解密
     * @param sourceBase64RSA
     * @param privateKeyBase64Str
     */
    public static String decode(String sourceBase64RSA){
        byte[] privateBytes = decodeBase64(PRIVATE_KEY);
        byte[] encodeSource = Base64.decodeBase64(sourceBase64RSA);
        int encodePartLen = encodeSource.length/ENCODE_PART_SIZE;
        List<byte[]> decodeListData = new LinkedList<>();//所有解密数据
        String decodeStrResult = null;
        //私钥解密
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(privateBytes);
        try {
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_RSA_TYPE);
            PrivateKey privateKey = keyFactory.generatePrivate(pkcs8EncodedKeySpec);
            Cipher cipher = Cipher.getInstance(KEY_RSA_TYPE);
            cipher.init(Cipher.DECRYPT_MODE,privateKey);
            int allDecodeByteLen = 0;//初始化所有被解密数据长度
            for (int i = 0; i < encodePartLen; i++) {
                byte[] tempEncodedData = new byte[ENCODE_PART_SIZE];
                System.arraycopy(encodeSource,i*ENCODE_PART_SIZE,tempEncodedData,0,ENCODE_PART_SIZE);
                byte[] decodePartData = cipher.doFinal(tempEncodedData);
                decodeListData.add(decodePartData);
                allDecodeByteLen += decodePartData.length;
            }
            byte [] decodeResultBytes = new byte[allDecodeByteLen];
            for (int i = 0,curPosition = 0; i < encodePartLen; i++) {
                byte[] tempSorceBytes = decodeListData.get(i);
                int tempSourceBytesLen = tempSorceBytes.length;
                System.arraycopy(tempSorceBytes,0,decodeResultBytes,curPosition,tempSourceBytesLen);
                curPosition += tempSourceBytesLen;
            }
            decodeStrResult = new String(decodeResultBytes,"UTF-8");
        }catch (Exception e){
            e.printStackTrace();
        }
        return decodeStrResult;
    }
}