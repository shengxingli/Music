package com.mo.music.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import com.mo.music.core.MyException;
import com.mo.music.core.MyList;
import com.mo.music.domain.Lyric;
import com.mo.music.domain.LyricDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * LyricService
 */
@Service
public class LyricService {

	@Autowired
	private LyricDao lyricDao;

	/**
	 * 通过歌曲Id查询歌词
	 * @param id
	 * @return
	 */
	public String queryMusicLyric(BigInteger id) {
		try {
			return lyricDao.queryMysicLyric(id);
		} catch (Exception e) {
			throw new MyException("该歌曲没有歌词", 404);
		}
	}

	public MyList<Lyric> queryAllLyric(int pageNum, int pageSize) {
		if (pageNum < 1) {
			throw new MyException("页码不正确", 400);
		}
		int limit = pageSize;
		int offset = (pageNum - 1) * pageSize;
		List<Lyric> list = lyricDao.queryAllLyric(limit, offset);
		int total = lyricDao.countAllLyric();
		return new MyList<>(list, total, pageNum, pageSize);
	}

	/**
	 * 新增歌词
	 * @param lyric
	 */
	@Transactional
	public void insertMusicLyric(Lyric lyric) {
		if (lyric.getLyric() == null || lyric.getLyric().equals("")) {
			throw new MyException("请输入歌词", 400);
		}
		if (lyric.getMusicId() == null) {
			throw new MyException("请选择歌词所属音乐", 400);
		}
		try {
			String lyricData = lyricDao.queryMysicLyric(lyric.getMusicId());
			if(lyricData != null && !lyricData.equals("")) {
				throw new Exception();
			}
		} catch (Exception e) {
			throw new MyException("该歌曲已有歌词", 400);
		}
		Timestamp current = new Timestamp(System.currentTimeMillis());
		lyric.setGmtCreate(current);
		lyric.setGmtModified(current);
		lyricDao.insertMysicLyric(lyric);
	}

	/**
	 * 更新歌词
	 * @param String lyricText
	 */
	public void updateMusicLyric(BigInteger musicId, String lyricText) {
		if (lyricText == null || lyricText.equals("")) {
			throw new MyException("歌词不能为空", 400);
		}
		Timestamp gmtModified = new Timestamp(System.currentTimeMillis());
		lyricDao.updateMysicLyric(musicId, lyricText, gmtModified);
	}

	public void removeMusicLyric(BigInteger id) {
		try {
			lyricDao.removeLyric(id);
		} catch (Exception e) {
			throw new MyException("删除失败", 500);
		}
	}
}