package com.mo.music.controller;

import java.math.BigInteger;

import com.mo.music.core.MyList;
import com.mo.music.core.MyResult;
import com.mo.music.domain.Lyric;
import com.mo.music.service.LyricService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


/**
 * LyricController
 */
@RestController
@RequestMapping("/cms/lyrics")
public class CmsLyricController {

    @Autowired
    LyricService lyricService;

    @RequestMapping(value = "/upload", method = RequestMethod.POST)
    public MyResult<?> uploadLyricByMusicId(BigInteger musicId, String lyric) {
        MyResult<?> myResult = new MyResult<>();
        Lyric lyricDTO = new Lyric();
        lyricDTO.setLyric(lyric);
        lyricDTO.setMusicId(musicId);
        lyricService.insertMusicLyric(lyricDTO);
        return myResult;
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    public MyResult<?> updateLyric(BigInteger musicId, String lyric) {
        lyricService.updateMusicLyric(musicId, lyric);
        return new MyResult<>();
	}
	
	@RequestMapping(value="/list", method=RequestMethod.POST)
	public MyResult<MyList<Lyric>> queryAll(@RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(defaultValue = "10") Integer pageSize) {
		MyResult<MyList<Lyric>> myResult =  new MyResult<MyList<Lyric>>();
		MyList<Lyric> list = lyricService.queryAllLyric(pageNum, pageSize);
		myResult.setData(list);
		return myResult;
	}
	
}