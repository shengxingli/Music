package com.mo.music.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * MusicVideoService
 */
@Service
public class MusicVideoService {

    @Autowired
    MusicVideoService musicVideoService;

    // public My
    
}