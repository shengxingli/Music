package com.mo.music.core;

import java.sql.SQLSyntaxErrorException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.TypeMismatchException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * GlobalExceptionHandler 
 */
@ControllerAdvice
public class GlobalExceptionHandler  {

	@ExceptionHandler(value = MyException.class)
	@ResponseBody
	public Map<String, Object> myExceptionHandler(HttpServletRequest req, MyException e) {
		Map<String, Object> map = new HashMap<>();
		map.put("code", e.getCode());
		map.put("data", null);
		map.put("msg", e.getMessage());
		return map;
	}
	
	@ExceptionHandler(value = MissingServletRequestParameterException.class)
	@ResponseBody
	public Map<String, Object> badExceptionHandler(HttpServletRequest req, MissingServletRequestParameterException e) {
		Map<String, Object> map = new HashMap<>();
		map.put("code", 400);
		map.put("data", null);
		map.put("msg", e.getMessage());
		return map;
	}
	
	@ExceptionHandler(value = TypeMismatchException.class)
	@ResponseBody
	public Map<String, Object> badExceptionHandler(HttpServletRequest req, TypeMismatchException e) {
		Map<String, Object> map = new HashMap<>();
		map.put("code", 400);
		map.put("data", null);
		map.put("msg", e.getMessage());
		return map;
	}

	@ExceptionHandler(value = Exception.class)
	@ResponseBody
	public Map<String, Object> exceptionHandler(HttpServletRequest req, Exception e) {
		Map<String, Object> map = new HashMap<>();
		map.put("code", 500);
		map.put("data", null);
		map.put("msg", "服务器异常");
		System.out.println(e);
		return map;
	}

	@ExceptionHandler(value = SQLSyntaxErrorException.class)
	@ResponseBody
	public Map<String, Object> sqlExceptionHandler(HttpServletRequest req, Exception e) {
		Map<String, Object> map = new HashMap<>();
		map.put("code", 500);
		map.put("data", null);
		map.put("msg", "服务器异常");
		System.out.println(e);
		return map;
	}
}