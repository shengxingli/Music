package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;

/**
 * AlbumMusic
 */
public class AlbumMusic {

    private BigInteger id;

    private BigInteger musicId;

    private String musicName;

    private BigInteger singerId;

    private String singerName;

    private BigInteger albumId;

    private Timestamp gmtCreate;

    private Timestamp gmtModified;

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public BigInteger getMusicId() {
        return musicId;
    }

    public void setMusicId(BigInteger musicId) {
        this.musicId = musicId;
    }

    public BigInteger getAlbumId() {
        return albumId;
    }

    public void setAlbumId(BigInteger albumId) {
        this.albumId = albumId;
    }

    public Timestamp getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Timestamp gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Timestamp getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Timestamp gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getMusicName() {
        return musicName;
    }

    public void setMusicName(String musicName) {
        this.musicName = musicName;
    }

    public BigInteger getSingerId() {
        return singerId;
    }

    public void setSingerId(BigInteger singerId) {
        this.singerId = singerId;
    }

    public String getSingerName() {
        return singerName;
    }

    public void setSingerName(String singerName) {
        this.singerName = singerName;
    }
}