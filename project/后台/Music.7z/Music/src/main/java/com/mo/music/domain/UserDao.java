package com.mo.music.domain;

import java.math.BigInteger;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

/**
 * UserDao
 */
@Mapper
public interface UserDao {

	/** 通过ID查询用户 */
	@Select("SELECT id, user_name, user_nickname, user_mobile, user_email, singer_id, user_avatar, user_sex, count_like, user_age, user_job, gmt_create, gmt_modified FROM user WHERE id = #{id}")
	User queryUserById(@Param("id") BigInteger id);

	/**
	 * 通过用户名查询用户
	 * @param userName
	 * @return
	 */
	@Select("select id, user_name, user_nickname, user_mobile, user_email, singer_id, user_avatar, user_sex, count_like, user_age, user_job, gmt_create, gmt_modified FROM user WHERE user_name = #{userName}")
	User queryUserByUserName(@Param("userName") String userName);
	
	/**
	 * 插入新用户并返回id
	 * @param user
	 * @return
	 */
	@Insert("INSERT INTO user (user_name, gmt_create, gmt_modified) VALUES (#{userName}, #{gmtCreate}, #{gmtModified}) ")
	@SelectKey(statement="SELECT LAST_INSERT_ID()" ,keyProperty="id", before=false, resultType=java.math.BigInteger.class)
	void insertUser(User user);

	/**
	 * 更新用户信息
	 * @param user
	 */
	@Update("UPDATE user SET user_nickname=#{userNickname}, user_mobile=#{userMobile}, user_email=#{userEmail}, user_avatar=#{userAvatar}, user_sex=#{userSex}, user_age=#{userAge}, user_job=#{userJob} gmt_modified=#{gmtModified} WHERE id=#{id}")
	void updateUserInfo(User user);

	@Update("UPDATE user SET singer_id=#{singerId} WHERE id=#{id}")
	void updateUserSinger(@Param("id") BigInteger id, @Param("singerId") BigInteger singerId );

	/**
	 * 查找全部用户
	 * @param name
	 * @param limit
	 * @param offset
	 * @return
	 */
	@Select("SELECT id, user_name, user_nickname, user_avatar, user_sex, count_like, user_age, user_job, gmt_create, gmt_modified FROM user WHERE user_name LIKE CONCAT('%%', #{name}, '%%') LIMIT #{limit} OFFSET #{offset}")
	List<User> queryAllUserByName(@Param("name") String name, @Param("limit") int limit, @Param("offset") int offset);	

	@Select("SELECT COUNT(id) FROM user WHERE user_name LIKE CONCAT('%%', #{name}, '%%')")
	Integer countUserByName(@Param("name") String name);
}