package com.mo.music.domain;

import java.math.BigInteger;
import java.sql.Timestamp;

/**
 * UserDao
 */
public class User {

	/** id */
	private BigInteger id;

	/** 用户登录名 */
	private String userName;

	/** 用户昵称 */
	private String userNickname;

	private String userMobile;

	private String userEmail;

	/** 歌手id, */
	private BigInteger singerId;

	/** 用户头像 */
	private String userAvatar;

	/** 用户性别 */
	private Integer userSex;

	/** 用户收藏数量 */
	private Integer countLike;

	/** 用户年龄 */
	private Integer userAge;

	/** 用户工作 */
	private String userJob;

	/** 生成时间 */
	private Timestamp gmtCreate;

	/** 更新时间 */
	private Timestamp gmtModified;

	/**
	 * @return the id
	 */
	public BigInteger getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(BigInteger id) {
		this.id = id;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the userAvatar
	 */
	public String getUserAvatar() {
		return userAvatar;
	}

	/**
	 * @param userAvatar the userAvatar to set
	 */
	public void setUserAvatar(String userAvatar) {
		this.userAvatar = userAvatar;
	}

	/**
	 * @return the userSex
	 */
	public Integer getUserSex() {
		return userSex;
	}

	/**
	 * @param userSex the userSex to set
	 */
	public void setUserSex(Integer userSex) {
		this.userSex = userSex;
	}

	/**
	 * @return the countLike
	 */
	public Integer getCountLike() {
		return countLike;
	}

	/**
	 * @param countLike the countLike to set
	 */
	public void setCountLike(Integer countLike) {
		this.countLike = countLike;
	}

	/**
	 * @return the userAge
	 */
	public Integer getUserAge() {
		return userAge;
	}

	/**
	 * @param userAge the userAge to set
	 */
	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}

	/**
	 * @return the userJob
	 */
	public String getUserJob() {
		return userJob;
	}

	/**
	 * @param userJob the userJob to set
	 */
	public void setUserJob(String userJob) {
		this.userJob = userJob;
	}

	/**
	 * @return the gmtCreate
	 */
	public Timestamp getGmtCreate() {
		return gmtCreate;
	}

	/**
	 * @param gmtCreate the gmtCreate to set
	 */
	public void setGmtCreate(Timestamp gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	/**
	 * @return the gmtModified
	 */
	public Timestamp getGmtModified() {
		return gmtModified;
	}

	/**
	 * @param gmtModified the gmtModified to set
	 */
	public void setGmtModified(Timestamp gmtModified) {
		this.gmtModified = gmtModified;
	}

	public String getUserNickname() {
		return userNickname;
	}

	public void setUserNickname(String userNickname) {
		this.userNickname = userNickname;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public BigInteger getSingerId() {
		return singerId;
	}

	public void setSingerId(BigInteger singerId) {
		this.singerId = singerId;
	}

}