package com.mo.music.domain;

import java.math.BigInteger;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

/**
 * MusicDao
 */
@Mapper
public interface MusicDao {

	/**
	 * 通过歌曲名称查询音乐
	 * @param name
	 * @param limit
	 * @param offset
	 * @return
	 */
	@Select("SELECT id, music_name, music_singer_name, music_singer_id, music_lyrics, music_compose, music_album, music_url, music_duration, music_album_id, is_online, count_visited, count_collected, gmt_modified, gmt_create FROM music WHERE music_name LIKE CONCAT('%%',#{name},'%%') LIMIT #{limit} OFFSET #{offset}" )	
	List<Music> queryMusicByMusicName(@Param("name") String name, @Param("limit") int limit, @Param("offset") int offset);

	/**
	 * 通过歌手名称查询音乐
	 * @param name
	 * @param limit
	 * @param offset
	 * @return
	 */
	@Select("SELECT id, music_name, music_singer_name, music_singer_id, music_lyrics, music_compose, music_album, music_url, music_duration, music_album_id, is_online, count_visited, count_collected FROM music WHERE singer_name LIKE CONCAT('%%',#{name},'%%') LIMIT #{limit} OFFSET #{offset}" )	
	List<Music> queryMusicBySingerName(@Param("name") String name, @Param("limit") int limit, @Param("offset") int offset);

	/** 最热音乐top50 */
	@Select("SELECT id, music_name, music_singer_name, music_singer_id, music_lyrics, music_compose, music_album, music_url, music_duration, music_album_id, is_online, count_visited, count_collected FROM music ORDER BY count_visited DESC LIMIT 50" )	
	List<Music> queryHotMusic();

	/** 最热音乐top50 */
	@Select("SELECT id, music_name, music_singer_name, music_singer_id, music_lyrics, music_compose, music_album, music_url, music_duration, music_album_id, is_online, count_visited, count_collected FROM music ORDER BY gmt_create DESC LIMIT 50" )	
	List<Music> queryNewMusic();

	/**
	 * 通过歌手id查询该歌手最热音乐
	 * @param name
	 * @param limit
	 * @param offset
	 * @return
	 */
	@Select("SELECT id, music_name, music_singer_name, music_singer_id, music_lyrics, music_compose, music_album, music_url, music_duration, music_album_id, is_online, count_visited, count_collected FROM music WHERE music_singer_id=#{singerId} ORDER BY count_visited DESC LIMIT 10" )	
	List<Music> queryHotMusicBySingerId(@Param("singerId") BigInteger singerId);

	/**
	 * 通过歌手id查询该歌手音乐
	 * @param name
	 * @param limit
	 * @param offset
	 * @return
	 */
	@Select("SELECT id, music_name, music_singer_name, music_singer_id, music_lyrics, music_compose, music_album, music_url, music_duration, music_album_id, is_online, count_visited, count_collected FROM music WHERE music_singer_id=#{singerId} LIMIT #{limit} OFFSET #{offset}" )	
	List<Music> queryMusicBySingerId(@Param("singerId") BigInteger singerId, @Param("limit") int limit, @Param("offset") int offset);
	@Select("SELECT COUNT(id) FROM music WHERE music_singer_id=#{singerId}" )	
	Integer countMusicBySingerId(@Param("singerId") BigInteger singerId);

	/**
	 * 统计通过名称可以查询到多少音乐的数量
	 * @param name
	 * @return
	 */
	@Select("SELECT COUNT(id) FROM music WHERE music_name LIKE #{name} or music_name LIKE CONCAT(#{name},'%') or music_name LIKE CONCAT('%',#{name},'%')")
	Integer countMusicNumberByMusicName(@Param("name") String name);

	/**
	 * 统计通过歌手名称可以查询到多少音乐的数量
	 * @param name
	 * @return
	 */
	@Select("SELECT COUNT(id) FROM music WHERE singer_name LIKE #{name} or singer_name LIKE CONCAT(#{name},'%') or singer_name LIKE CONCAT('%',#{name},'%')")
	Integer countMusicNumberBySingerName(@Param("name") String name);

	/**
	 * 查找单曲
	 * @param id
	 * @return
	 */
	@Select("SELECT id, music_name, music_singer_id, music_singer_name, music_lyrics, music_compose, music_album, music_url, music_duration, music_album_id, is_online, count_visited, count_collected, gmt_create, gmt_modified FROM music WHERE id = #{id}")	
	Music queryMusicById(@Param("id") BigInteger id);

	/**
	 * 更新歌曲状态
	 * @param music
	 */
	@Update("UPDATE music SET is_online=#{isOnline}, gmt_modified=#{gmtModified} WHERE id = #{id}")
	void updateMusicOnline(Music music);

	/**
	 * 新增音乐
	 * @param music
	 */
	@Insert("INSERT INTO music (music_name, music_singer_name, music_singer_id, music_compose, music_lyrics, music_duration, music_album, music_album_id, music_url, music_time, gmt_modified, gmt_create, is_online) VALUES (#{musicName}, #{musicSingerName}, #{musicSingerId}, #{musicCompose}, #{musicLyrics}, #{musicDuration}, #{musicAlbum}, #{musicAlbumId}, #{musicUrl}, #{musicTime}, #{gmtModified}, #{gmtCreate}, #{isOnline})")
	@SelectKey(statement="SELECT LAST_INSERT_ID()" ,keyProperty="id", before=false, resultType=java.math.BigInteger.class)
	void insertMusic(Music music);

	/**
	 * 更新歌曲信息
	 * @param music
	 */
	@Update("UPDATE music SET music_name=#{musicName}, music_singer_id=#{musicSingerId}, music_singer_name=#{musicSingerName}, music_compose=#{musicCompose}, music_lyrics=#{musicLyrics}, music_duration=#{musicDuration}, music_album=#{musicAlbum}, music_album_id=#{musicAlbumId}, music_url=#{musicUrl}, music_time=#{musicTime}, gmt_modified=#{gmtModified}, is_online=#{isOnline} WHERE id = #{id}")
	void updateMusic(Music music);

	/** 访问数量加一 */
	@Update("UPDATE music SET count_visited=count_visited+1 WHERE id=#{id} ")
	void increaseCountVisited(@Param("id") BigInteger id);

	/** 收藏数量加一 */
	@Update("UPDATE music SET count_collected=count_collected+1 WHERE id=#{id} ")
	void increaseCountCollected(@Param("id") BigInteger id);

	/** 收藏数量减一 */
	@Update("UPDATE music SET count_collected=count_collected-1 WHERE id=#{id} ")
	void reduceCountCollected(@Param("id") BigInteger id);


}