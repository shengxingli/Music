package com.mo.music.controller;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mo.music.core.JWTToken;
import com.mo.music.core.MyException;
import com.mo.music.core.MyResult;
import com.mo.music.core.MyUtils;
import com.mo.music.core.RSAUtils;
import com.mo.music.core.UserLoginToken;
import com.mo.music.domain.Album;
import com.mo.music.domain.Lyric;
import com.mo.music.domain.Music;
import com.mo.music.domain.Singer;
import com.mo.music.domain.SingerApply;
import com.mo.music.domain.User;
import com.mo.music.service.AlbumService;
import com.mo.music.service.LyricService;
import com.mo.music.service.MusicService;
import com.mo.music.service.SingerApplyService;
import com.mo.music.service.SingerService;
import com.mo.music.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * UserController
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

	@Autowired
	private SingerApplyService singerApplyService;

	@Autowired
	private MusicService musicService;

	@Autowired
	private SingerService singerService;

	@Autowired
	private LyricService lyricService;

	@Autowired
	private AlbumService albumService;

	/** 登录 */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public MyResult<String> login(HttpServletResponse httpServletResponse , @RequestParam(required = false) String userName, @RequestParam(required = false) BigInteger id, String password) {
		String token;
        if (userName != null) {
            token = userService.loginByUserName(userName, password);
        } else if (id != null) {
            token = userService.loginById(id, password);
		} else {
			throw new MyException("请检查帐号", 400);
		}
		MyResult<String> myResult = new MyResult<>();
		myResult.setData(token);
		Cookie cookie;
		if (userName.equals("admin")) {
			cookie = new Cookie("sys_t", token);
		} else {
			cookie = new Cookie("t", token);
		}
		cookie.setPath("/");
		cookie.setMaxAge(3600 * 24);
		httpServletResponse.addCookie(cookie);
		return myResult;
	}

	/** 查询用户信息
	 */
	@UserLoginToken
	@RequestMapping(value = "/info", method = RequestMethod.POST)
	public MyResult<User> getUserInfo(HttpServletRequest httpServletRequest) {
		String t = MyUtils.getRequestParam("t", httpServletRequest);
		BigInteger selectId  = new BigInteger(JWTToken.getAudience(t).get(0));
		User user = userService.queryUserById(selectId);
		MyResult<User> myResult = new MyResult<>();
		myResult.setData(user);
		return myResult;
	}

	/**
	 * 更新用户信息
	 * @param user
	 * @return
	 */
	@UserLoginToken
	@RequestMapping(value = "/update", method = RequestMethod.POST )
	public MyResult<?> updateUserInfo(User user,HttpServletRequest httpServletRequest) {
		String t = MyUtils.getRequestParam("t", httpServletRequest);
		BigInteger id  = new BigInteger(JWTToken.getAudience(t).get(0));
		user.setId(id);
		userService.updateUser(user);
		return new MyResult<>();
	}

	/**	注册 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public MyResult<String> registerUser(HttpServletResponse httpServletResponse, String userName, String password, String confirmPassword) {
		if (!Pattern.matches("^[a-zA-Z]{1}[a-zA-Z0-9]{7,19}$", userName) || userName.length() > 20) {
			throw new MyException("用户名必须字母开头的8-20位组合");
		}
		if (!Pattern.matches("^[a-zA-Z0-9]{8,16}$", password)) {			
			throw new MyException("密码长度在8-16位字母数字组合");
		}
		if (!password.equals(confirmPassword)) {		
			throw new MyException("两次密码输入不一致");
		}
		String token = userService.insertUser(userName, RSAUtils.encode(password));
		MyResult<String> myResult = new MyResult<>();
		myResult.setData(token);
		Cookie cookie = new Cookie("t", token);
		httpServletResponse.addCookie(cookie);
		return myResult;
	}

	/**
	 * 申请成为歌手
	 * @param intro
	 * @param singerName
	 * @param singerAvatar
	 * @param httpServletRequest
	 * @return
	 */
	@UserLoginToken
	@RequestMapping(value = "/beSinger", method = RequestMethod.POST)
	public MyResult<?> toBeSinger(String intro, String singerName, String singerAvatar, HttpServletRequest httpServletRequest) { 
		if (intro == null || intro.equals("")) {
			throw new MyException("请填写证明资料", 400);
		} 
		if (singerName == null || singerName.equals("")) {
			throw new MyException("请填写证明资料", 400);
		}
		String t = MyUtils.getRequestParam("t", httpServletRequest);
		BigInteger id  = new BigInteger(JWTToken.getAudience(t).get(0));
		if (singerAvatar == null || singerAvatar.equals("")) {
			singerAvatar = userService.queryUserById(id).getUserAvatar();
		}
		SingerApply singerApply = singerApplyService.queryUserApplyStatus(id);
		if (singerApply == null ) {
			singerApplyService.insertSingerApply(id, intro, singerName, singerAvatar);
		} else if (singerApply.getStatus() == 1) {
			throw new MyException("您已通过审核", 400);
		} else if (singerApply.getStatus() != 1) {
			singerApplyService.updateSingerApplyIntro(id, singerName, singerAvatar, intro);
		}
		return new MyResult<>();
	}

	/**
	 * 查询用户申请入驻状态
	 * @param httpServletRequest
	 * @return
	 */
	@UserLoginToken
	@RequestMapping(value = "/querySingerStatus", method = RequestMethod.POST)
	public MyResult<SingerApply> querySingerStatus(HttpServletRequest httpServletRequest) {
		MyResult<SingerApply> myResult = new MyResult<>();
		String t = MyUtils.getRequestParam("t", httpServletRequest);
		BigInteger id  = new BigInteger(JWTToken.getAudience(t).get(0));
		SingerApply singerApply = singerApplyService.queryUserApplyStatus(id);
		myResult.setData(singerApply);
		return myResult;
	}

	/**
	 * 上传自己的音乐
	 * @param httpServletRequest
	 * @param musicName
	 * @param musicCompose
	 * @param musicLyrics
	 * @param musicDuration
	 * @param musicAlbum
	 * @param musicAlbumId
	 * @param musicUrl
	 * @param musicTime
	 * @param isOnline
	 * @param lyric
	 * @return
	 */
	@UserLoginToken
	@Transactional
	@RequestMapping(value = "/uploadMusic", method = RequestMethod.POST)
	public MyResult<?> uploadMusic(HttpServletRequest httpServletRequest, String musicName, String musicCompose, String musicLyrics, Integer musicDuration, String musicAlbum, BigInteger musicAlbumId, String musicUrl, Timestamp musicTime, Integer isOnline, String lyric) {
		String t = MyUtils.getRequestParam("t", httpServletRequest);
		BigInteger id  = new BigInteger(JWTToken.getAudience(t).get(0));
		User user = userService.queryUserById(id);
		BigInteger singerId = user.getSingerId();
		if (singerId == null) {
			throw new MyException("抱歉,您还没有上传音乐的资格,请先提交入驻申请", 403);
		}
		Singer singer = singerService.querySingerById(singerId);
		Music music = new Music();
		music.setIsOnline(isOnline);
		music.setMusicAlbum(musicAlbum);
		music.setMusicAlbumId(musicAlbumId);
		music.setMusicCompose(musicCompose);
		music.setMusicDuration(musicDuration);
		music.setMusicLyrics(musicLyrics);
		music.setMusicName(musicName);
		music.setMusicSingerId(singerId);
		music.setMusicSingerName(singer.getSingerName());
		music.setMusicTime(musicTime);
		music.setMusicUrl(musicUrl);
		musicService.createMusic(music);
		if (lyric != null && !lyric.equals("")) {
			Lyric lyricDto = new Lyric();
			lyricDto.setLyric(lyric);
			lyricDto.setMusicId(music.getId());
			lyricService.insertMusicLyric(lyricDto);
		}
		return new MyResult<>();
	}

	/**
	 * 启用自己的或者禁用自己的音乐
	 * @param musicId
	 * @param status
	 * @return
	 */
	@UserLoginToken
	@RequestMapping(value = "/updateMusicStatus", method = RequestMethod.POST)
	public MyResult<?> updateMusicStatus(BigInteger musicId, Integer status, HttpServletRequest httpServletRequest ) {
		String t = MyUtils.getRequestParam("t", httpServletRequest);
		BigInteger id  = new BigInteger(JWTToken.getAudience(t).get(0));
		User user = userService.queryUserById(id);
		if (musicService.queryMusicById(musicId, true).getMusicSingerId().compareTo(user.getSingerId()) != 0) {
			throw new MyException("该歌曲不属于该用户", 400);
		}
		musicService.ableMusicById(musicId, status);
		return new MyResult<>();
	}

	/**
	 * 创建自己的专辑
	 * @param albumName
	 * @param musicList
	 * @param httpServletRequest
	 * @return
	 */
	@Transactional
	@UserLoginToken
	@RequestMapping(value = "/createMyAlbum", method = RequestMethod.POST)
	public MyResult<?> createMyAlbum(String albumName, String musicList, HttpServletRequest httpServletRequest) {
		String t = MyUtils.getRequestParam("t", httpServletRequest);
		BigInteger id  = new BigInteger(JWTToken.getAudience(t).get(0));
		User user = userService.queryUserById(id);
		Singer singer = singerService.querySingerById(user.getSingerId());
		Album album = new Album();
		album.setAlbumName(albumName);
		album.setSingerId(user.getSingerId());
		album.setSingerName(singer.getSingerName());
		albumService.insertAlbum(album);
		if (musicList != null && musicList.length() > 0) {
			String[] ids = musicList.split(",");
			for (String musicId : ids) {
				BigInteger mId = new BigInteger(musicId);
				if (musicService.queryMusicById(mId).getMusicSingerId().compareTo(singer.getId()) != 0) {
					throw new MyException("专辑内包含不属于的音乐", 400);
				}
				albumService.insertMusicIntoAlbum(album.getId(), mId);
			}
		}
		return new MyResult<>();
	}

	/**
	 * 往自己的专辑里插入音乐
	 * @param albumId
	 * @param musicList
	 * @return
	 */
	@Transactional
	@UserLoginToken
	@RequestMapping(value = "/insertMusicIntoAlbum", method = RequestMethod.POST)
	public MyResult<?> insertMusicIntoAlbum(BigInteger albumId, String musicList, HttpServletRequest httpServletRequest) { 
		String t = MyUtils.getRequestParam("t", httpServletRequest);
		BigInteger id  = new BigInteger(JWTToken.getAudience(t).get(0));
		User user = userService.queryUserById(id);
		Singer singer = singerService.querySingerById(user.getSingerId());
		Album album = albumService.queryAlbumById(albumId);
		if (musicList != null && musicList.length() > 0) {
			String[] ids = musicList.split(",");
			for (String musicId : ids) {
				BigInteger mId = new BigInteger(musicId);
				if (musicService.queryMusicById(mId).getMusicSingerId().compareTo(singer.getId()) != 0) {
					throw new MyException("专辑内包含不属于的音乐", 400);
				}
				albumService.insertMusicIntoAlbum(album.getId(), mId);
			}
		}
		return new MyResult<>();
	}

	/**
	 * 自己专辑的状态
	 * @param albumId
	 * @param status
	 * @return
	 */
	@UserLoginToken
	@RequestMapping(value = "/updateAlbumStatus", method = RequestMethod.POST)
	public MyResult<?> updateAlbumStatus(BigInteger albumId, Integer status, HttpServletRequest httpServletRequest ) {
		String t = MyUtils.getRequestParam("t", httpServletRequest);
		BigInteger id  = new BigInteger(JWTToken.getAudience(t).get(0));
		User user = userService.queryUserById(id);
		if (albumService.queryAlbumById(albumId).getSingerId().compareTo(user.getSingerId()) != 0) {
			throw new MyException("该专辑不属于该歌手", 400);
		}
		albumService.ableAlbumById(albumId, status);
		return new MyResult<>();
	}


}