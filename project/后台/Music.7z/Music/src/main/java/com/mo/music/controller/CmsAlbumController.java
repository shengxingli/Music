package com.mo.music.controller;

import java.math.BigInteger;

import com.mo.music.core.MyException;
import com.mo.music.core.MyList;
import com.mo.music.core.MyResult;
import com.mo.music.domain.Album;
import com.mo.music.service.AlbumService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * CmsAlbumController.
 */
@RestController
@RequestMapping("/cms/album")
public class CmsAlbumController {

    @Autowired
    private AlbumService albumService;

    /**
     * 全部专辑
     * @param pageNum
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public MyResult<MyList<Album>> queryAlbumList(String name, @RequestParam(defaultValue = "1") Integer pageNum, @RequestParam(defaultValue = "10") Integer pageSize) {
        MyResult<MyList<Album>> myResult = new MyResult<>();
        MyList<Album> list = albumService.queryAllAlbum(name, pageNum, pageSize);
        myResult.setData(list);
        return myResult;
    }
    
    /**
     * 启用专辑
     * @param id
     * @return
     */
    @RequestMapping(value = "/enable", method = RequestMethod.POST)
    public MyResult<?> enableAlbum(BigInteger id) {
        albumService.ableAlbumById(id, 1);
        return new MyResult<>();
    }

    /**
     * 禁用专辑
     * @param id
     * @return
     */
    @RequestMapping(value = "/disable", method = RequestMethod.POST)
    public MyResult<?> disableAlbum(BigInteger id) {
        albumService.ableAlbumById(id, 0);
        return new MyResult<>();
    }

    /**
     * 查询单个专辑信息
     * @param id
     * @return
     */
    @RequestMapping(value = "/info", method = RequestMethod.POST)
    public MyResult<Album> queryInfo(BigInteger id) {
        Album album = albumService.queryAlbumById(id);
        MyResult<Album> myResult = new MyResult<>();
        myResult.setData(album);
        return myResult;
    }

    /**
     * 新增以及编辑
     * @param album
     * @return
     */
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public MyResult<?> editAlbum(Album album) {
        if (album.getId() == null) {
            albumService.insertAlbum(album);
        } else {
            try {
                albumService.queryAlbumById(album.getId());
                albumService.updateAlbum(album);
            } catch (Exception e) {
                throw new MyException("id不正确", 400);
            }
        }
        return new MyResult<>();
    }

    /**
     * 专辑内插入音乐
     * @param albumId
     * @param musicId
     * @return
     */
    @RequestMapping(value = "/insertMusic", method = RequestMethod.POST)
    public MyResult<?> insertMusic(BigInteger albumId, BigInteger musicId) {
        albumService.insertMusicIntoAlbum(albumId, musicId);
        return new MyResult<>();
    }

    /**
     * 删除专辑内的某个音乐
     * @param albumId
     * @param musicId
     * @return
     */
    @RequestMapping(value = "/removeMusic", method = RequestMethod.POST)
    public MyResult<?> removeMusic(BigInteger albumId, BigInteger musicId) {
        albumService.removeAlbumMusic(albumId, musicId);
        return new MyResult<>();
    }
}